import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import * as dotenv from "dotenv";

dotenv.config();

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: { headers: { "User-Agent": "aistudio-build" } }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.post("/api/gemini/whatsapp", async (req, res) => {
    try {
      const { userText, history } = req.body;
      const systemInstruction = `You are AVG's AI assistant for Verified Printing Machinery Exchange — India's trusted used printing press marketplace. Your role:
1. VALUATE used printing presses (provide realistic INR Lakh ranges based on machine brand, year, impressions, and Indian market conditions)
2. QUALIFY leads — identify if user is buyer or seller, extract machine details
3. ASSIGN broker zone — based on location, assign the nearest Indian printing hub broker
4. CREATE a CRM summary card

Always respond in this format:
RESPONSE: [Your conversational reply in 2-3 sentences, professional but warm, mix of English and Hindi where appropriate]
CRM_JSON: {"client":"[inferred name or 'Prospect']","machine":"[machine details]","location":"[city/zone]","value":"[INR range in Lakhs]","broker":"[nearest hub broker name + city]","technician":"[regional tech name]","type":"[buyer/seller/inquiry]","action":"[next step]"}

Be specific with valuations. Heidelberg SM 74-4 (2008) = ₹45-55L. Komori Lithrone L429 (2012) = ₹65-75L. Ryobi 924 (2015) = ₹18-25L. KBA Rapida 74 (2010) = ₹55-70L. For unknown machines, give a reasonable range based on type.`;

      const contents = [];
      if (history && Array.isArray(history)) {
        for (const msg of history) {
          contents.push({ role: msg.role === 'user' ? 'user' : 'model', parts: [{ text: msg.text }] });
        }
      }
      contents.push({ role: "user", parts: [{ text: userText }] });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });
      
      const fullText = response.text || '';
      const responseMatch = fullText.match(/RESPONSE:\s*([\s\S]*?)(?:CRM_JSON:|$)/i);
      const crmMatch = fullText.match(/CRM_JSON:\s*(\{[\s\S]*\})/i);
      
      const reply = responseMatch ? responseMatch[1].trim() : fullText;
      let crmData = null;
      if (crmMatch) {
         try {
           crmData = JSON.parse(crmMatch[1]);
         } catch(e) {}
      }

      res.json({ reply, crmData });
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });


  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
