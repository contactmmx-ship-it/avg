import { useState } from "react";
import { PLAN_SECTIONS } from "../data";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, Layers, Briefcase, Cpu, Landmark, Waypoints } from "lucide-react";

export function BlueprintPanel() {
  const cats = [
    { label: 'All', icon: <Layers size={14} /> },
    { label: 'Strategy', icon: <Sparkles size={14} /> },
    { label: 'Operations', icon: <Briefcase size={14} /> },
    { label: 'Technology', icon: <Cpu size={14} /> },
    { label: 'Financials', icon: <Landmark size={14} /> },
    { label: 'Roadmap', icon: <Waypoints size={14} /> }
  ];
  
  const [currentCat, setCurrentCat] = useState("All");
  const [currentSec, setCurrentSec] = useState(PLAN_SECTIONS[0]);

  const displayedSections = currentCat === "All" ? PLAN_SECTIONS : PLAN_SECTIONS.filter(s => s.cat === currentCat);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center bg-white/50 backdrop-blur rounded-2xl p-6 border border-white/40 shadow-sm">
        <div>
          <h2 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-indigo-800 mb-1 flex items-center gap-2">
            <Layers className="text-blue-600" size={20} />
            B2B Corporate Blueprint
          </h2>
          <p className="text-sm text-slate-500 font-medium">Authoritative master plan and structural framework</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        {cats.map(c => (
          <button 
            key={c.label}
            onClick={() => {
              setCurrentCat(c.label);
              const firstMatch = c.label === "All" ? PLAN_SECTIONS[0] : PLAN_SECTIONS.find(s => s.cat === c.label);
              if (firstMatch) setCurrentSec(firstMatch);
            }}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-[12px] font-bold border transition-all duration-300 ${currentCat === c.label ? "bg-white text-blue-700 border-blue-200/60 shadow-[0_4px_15px_rgba(59,130,246,0.1)] ring-2 ring-blue-500/20" : "bg-white/50 text-slate-500 border-slate-200/50 hover:bg-white hover:text-slate-900 shadow-sm hover:shadow-md"}`}
          >
            {c.icon} {c.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-8 items-start relative pb-10">
        <div className="flex flex-col gap-2 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
          {displayedSections.map((s, idx) => (
            <motion.button
               initial={{ opacity: 0, x: -10 }}
               animate={{ opacity: 1, x: 0 }}
               transition={{ delay: idx * 0.05 }}
               key={s.id}
               onClick={() => setCurrentSec(s)}
               className={`group relative px-5 py-4 rounded-2xl text-left text-[13px] font-semibold transition-all border overflow-hidden ${currentSec.id === s.id ? "bg-white text-blue-700 border-blue-200/60 shadow-lg ring-1 ring-blue-500/10" : "bg-transparent text-slate-600 border-transparent hover:bg-white/80 hover:text-slate-900 hover:border-slate-200 hover:shadow-sm"}`}
            >
              {currentSec.id === s.id && (
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-500 to-indigo-600" />
              )}
              {s.title}
            </motion.button>
          ))}
        </div>
        
        <div className="bg-white/80 backdrop-blur-xl border border-white/60 rounded-3xl p-10 shadow-xl shadow-slate-200/50 relative overflow-hidden">
           <div className="absolute top-0 right-0 w-64 h-64 bg-blue-100/50 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
           <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-50/50 rounded-full blur-3xl -ml-20 -mb-20 pointer-events-none"></div>
           
           <AnimatePresence mode="wait">
             <motion.div
               key={currentSec.id}
               initial={{ opacity: 0, y: 15 }}
               animate={{ opacity: 1, y: 0 }}
               exit={{ opacity: 0, y: -15 }}
               transition={{ duration: 0.3, ease: "easeOut" }}
               className="relative z-10"
             >
               <h3 className="text-2xl font-black text-slate-800 mb-8 tracking-tight">{currentSec.title}</h3>
               <div className="text-[14px] text-slate-700 whitespace-pre-wrap leading-relaxed max-h-[550px] overflow-y-auto pr-6 custom-scrollbar font-medium">
                 {currentSec.content}
               </div>
             </motion.div>
           </AnimatePresence>
        </div>
      </div>
    </div>
  )
}
