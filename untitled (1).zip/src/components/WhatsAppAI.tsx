import { useState, useRef, useEffect } from "react";
import { WA_PRESETS } from "../data";
import { useAuth } from "../AuthContext";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { doc, setDoc } from "firebase/firestore";
import { Bot, Send, User, ChevronRight, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface WaMsg {
  role: "bot" | "user";
  text: string;
}

export function WhatsAppAI() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<WaMsg[]>([
    {role: 'bot', text: 'Namaste! Welcome to AVG Verified Printing Machinery Exchange. I am powered by Gemini AI and can instantly appraise any used printing press, qualify your listing, and route your lead to the nearest verified broker. What machine are you working with today?'}
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [crmData, setCrmData] = useState<any>(null);
  const endRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => endRef.current?.scrollIntoView({ behavior: "smooth" });
  useEffect(() => scrollToBottom(), [messages, loading]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;
    const userMsg = { role: "user" as const, text };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/gemini/whatsapp", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
           userText: text,
           history: messages
        })
      });
      const data = await res.json();
      
      setMessages(prev => [...prev, {role: "bot", text: data.reply}]);
      
      if (data.crmData) {
        setCrmData(data.crmData);
        if (user) {
          const leadId = `LD-${Date.now()}`;
          await setDoc(doc(db, "crm_leads", leadId), {
             ownerId: user.uid,
             ...data.crmData,
             createdAt: new Date()
          });
        }
      }
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, {role: "bot", text: "I apologize, the AI engine is currently unavailable."}]);
    }
    setLoading(false);
  }

  return (
    <div className="space-y-8 pb-10">
      <div className="flex justify-between items-center bg-white/50 backdrop-blur rounded-2xl p-6 border border-white/40 shadow-sm">
        <div>
          <h2 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-indigo-800 mb-1 flex items-center gap-2">
            <Bot className="text-blue-600" size={20} />
            WhatsApp AI Lead Engine
          </h2>
          <p className="text-sm text-slate-500 font-medium">Powered by real Gemini AI — type any machine, location, or query</p>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <div className="flex flex-col gap-5">
          <div className="flex flex-wrap gap-2">
             {WA_PRESETS.map((p, i) => (
                <button
                  key={i}
                  onClick={() => sendMessage(p.text)}
                  className="px-4 py-2 bg-white/80 backdrop-blur border border-white hover:border-blue-200 text-slate-600 rounded-xl text-[11px] font-bold hover:bg-white hover:text-blue-700 shadow-sm hover:shadow-md transition-all flex items-center gap-1.5 group"
                >
                  {p.label}
                  <ChevronRight size={12} className="opacity-50 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all text-blue-500" />
                </button>
             ))}
          </div>

          <div className="border border-white/60 bg-white/40 backdrop-blur-xl rounded-3xl overflow-hidden h-[540px] flex flex-col shadow-xl shadow-blue-900/5">
            <div className="bg-gradient-to-r from-[#0f172a] to-[#1e293b] px-5 py-4 flex items-center justify-between shadow-lg relative z-20 border-b border-indigo-500/20">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
              <div className="flex items-center gap-4 relative z-10">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-[12px] font-black text-white shrink-0 shadow-[0_0_15px_rgba(59,130,246,0.5)] border border-blue-400/50">AVG</div>
                <div>
                  <div className="text-[14px] font-bold text-white tracking-tight">AVG Print Verification Bot</div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_5px_rgba(16,185,129,1)]"></span>
                    <div className="text-[10px] text-emerald-400 font-bold tracking-widest uppercase">Gemini AI Engine Online</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-5 custom-scrollbar bg-[#f8fafc]/80 relative z-10">
               {messages.map((m, i) => (
                 <motion.div initial={{ opacity: 0, y: 10, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.3 }} key={i} className={`flex gap-3 max-w-[85%] ${m.role === 'bot' ? 'self-start' : 'self-end flex-row-reverse'}`}>
                    {m.role === 'bot' ? (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 shrink-0 border border-blue-200 flex items-center justify-center text-blue-600 shadow-sm mt-1">
                        <Bot size={14} />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-slate-200 shrink-0 border border-slate-300 flex items-center justify-center text-slate-500 shadow-sm mt-1">
                        <User size={14} />
                      </div>
                    )}
                    <div className={`p-4 text-[13px] leading-relaxed shadow-sm ${m.role === 'bot' ? 'bg-white text-slate-700 rounded-2xl rounded-tl-sm border border-slate-200/60' : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl rounded-tr-sm shadow-blue-500/20'}`}>
                      {m.role === 'bot' && <p className="text-[10px] font-black tracking-widest uppercase text-blue-600 mb-1.5">AI Engine</p>}
                      <div className="whitespace-pre-line font-medium">{m.text}</div>
                    </div>
                 </motion.div>
               ))}
               
               <AnimatePresence>
                 {loading && (
                   <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }} className="flex gap-3 max-w-[85%] self-start">
                     <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 shrink-0 border border-blue-200 flex items-center justify-center text-blue-600 shadow-sm mt-1">
                        <Bot size={14} />
                      </div>
                     <div className="p-4 text-xs text-slate-500 font-medium italic bg-white border border-slate-200/60 rounded-2xl rounded-tl-sm shadow-sm flex items-center gap-2">
                       <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></div>
                       <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse delay-150"></div>
                       <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse delay-300"></div>
                       Processing intelligence...
                     </div>
                   </motion.div>
                 )}
               </AnimatePresence>
               <div ref={endRef} />
            </div>

            <div className="bg-white/80 backdrop-blur px-4 py-4 flex gap-3 border-t border-slate-200/60 items-end relative z-20">
               <textarea
                 value={input}
                 onChange={e => setInput(e.target.value)}
                 onKeyDown={e => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(input); } }}
                 placeholder="Type machine model, location, or query..."
                 className="flex-1 bg-white border border-slate-300 rounded-2xl px-5 py-3.5 text-[13px] font-medium text-slate-900 outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 placeholder-slate-400 resize-none shadow-sm transition-all custom-scrollbar"
                 rows={1}
               />
               <button onClick={() => sendMessage(input)} className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white w-12 h-12 rounded-2xl flex items-center justify-center hover:shadow-[0_4px_15px_rgba(59,130,246,0.4)] transition-all shrink-0">
                  <Send size={18} className="translate-x-[-1px] translate-y-[1px]" />
               </button>
            </div>
          </div>
        </div>

        <div>
           {!crmData ? (
             <div className="h-full bg-white/60 backdrop-blur border border-white rounded-3xl p-10 flex flex-col justify-center items-center text-center text-slate-500 text-xs shadow-sm min-h-[500px]">
                <div className="w-20 h-20 mb-6 bg-slate-100 rounded-3xl flex items-center justify-center border border-slate-200/60 shadow-inner">
                  <Bot size={32} className="text-slate-300" />
                </div>
                <h4 className="text-sm font-black tracking-widest uppercase text-slate-800 mb-2">CRM Lead Dashboard</h4>
                <div className="font-medium text-slate-400">Waiting for intelligence stream...<br/>Send a message to generate a structured lead card.</div>
             </div>
           ) : (
             <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-white/90 backdrop-blur-xl border border-white/60 rounded-3xl shadow-xl shadow-blue-900/5 flex flex-col h-full overflow-hidden relative">
                <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
                <div className="p-6 border-b border-slate-200/50 flex items-center justify-between bg-emerald-50/30 relative z-10">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 size={18} className="text-emerald-500" />
                    <h4 className="text-sm font-black tracking-tight text-slate-900 uppercase">Live CRM Integration</h4>
                  </div>
                  <span className="font-mono text-[11px] bg-white text-slate-600 px-3 py-1.5 rounded-lg border border-slate-200 shadow-sm font-bold">AVG-LD-{Math.floor(Math.random()*9000+1000)}</span>
                </div>

                <div className="p-8 flex-1 flex flex-col justify-between relative z-10">
                  <div>
                    <div className="mb-8 flex justify-between items-center bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                      <div>
                        <div className="text-[10px] font-black text-slate-400 tracking-widest uppercase mb-2">Lead Classification</div>
                        <span className={`px-4 py-1.5 rounded-lg text-[11px] font-black uppercase tracking-widest inline-flex ${crmData.type === 'seller' ? 'bg-amber-100 text-amber-700 border border-amber-200' : crmData.type === 'buyer' ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' : 'bg-blue-100 text-blue-700 border border-blue-200'}`}>
                          {crmData.type || 'inquiry'}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] font-black text-slate-400 tracking-widest uppercase mb-2">Estimated Value</div>
                        <span className="text-2xl font-black text-slate-900">{crmData.value}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-x-8 gap-y-6">
                      {[
                        {l: 'Client / Origin', v: crmData.client},
                        {l: 'Target Machine', v: crmData.machine},
                        {l: 'Regional Hub', v: crmData.location},
                        {l: 'Broker Assignment', v: crmData.broker},
                        {l: 'Field Technician', v: crmData.technician},
                        {l: 'Next Workflow Action', v: crmData.action, colSpan: 2}
                      ].map(f => (
                         <div key={f.l} className={f.colSpan ? 'col-span-2' : ''}>
                            <div className="text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5">{f.l}</div>
                            <div className="text-[14px] font-bold text-slate-800 leading-snug">{f.v || '—'}</div>
                            {f.colSpan && <div className="h-0.5 w-full bg-slate-100 mt-5 rounded-full"></div>}
                         </div>
                      ))}
                    </div>
                  </div>

                  <button className="w-full py-4 mt-10 bg-gradient-to-r from-slate-900 to-slate-800 hover:from-slate-800 hover:to-slate-700 text-white rounded-2xl text-[13px] font-bold transition-all shadow-[0_4px_15px_rgba(15,23,42,0.3)] uppercase tracking-[0.2em]">
                    Submit Lead & Notify Regional Hub
                  </button>
                </div>
             </motion.div>
           )}
        </div>
      </div>
    </div>
  )
}
