import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Layers, Package, Settings2, Activity,
  Maximize2, ArrowRight, CheckCircle2, AlertCircle, Share2, QrCode,
  FileText, TrendingUp, Sparkles, Printer, Copy, RotateCcw, Sliders
} from "lucide-react";

// ==========================================
// REUSABLE MACHINE DATA SCHEMA & INTERFACES 
// ==========================================
export interface PrintingMachineSpec {
  make: string;
  model: string;
  year: number;
  serialNumber: string;
  weight: string;
  maxSpeed: string;
  maxSheetSize: string;
  minSheetSize: string;
  printUnitsCount: number;
  totalImpressions: number; // in millions
  coatingUnit: string;
}

export interface ComponentCondition {
  part: string;
  newBaseline: string;
  currentWear: string;
  status: "excellent" | "good" | "warning" | "danger";
  operationalHours: number;
}

export interface HealthMetric {
  category: string;
  score: number;
  grade: string;
  description: string;
}

export interface MachineTwinData {
  id: string; // Unique twin ID, for QR/Passport integration
  specifications: PrintingMachineSpec;
  components: ComponentCondition[];
  health: HealthMetric[];
  valuation: {
    originalValueUSD: number;
    currentEstimatedValueUSD: number;
    depreciationRateAnnualPercent: number;
  };
}

// ==========================================
// PRESETS / SAMPLE DATA (HEIDELBERG OFFSET PRESSES)
// ==========================================
const HEIDELBERG_PRESETS: Record<string, MachineTwinData> = {
  "Speedmaster XL 106-6+L": {
    id: "HDB-XL106-6L-2019-883",
    specifications: {
      make: "Heidelberg",
      model: "Speedmaster XL 106-6+L",
      year: 2019,
      serialNumber: "HDB-XL106-99201A",
      weight: "43,500 kg",
      maxSpeed: "18,000 sheets/hr",
      maxSheetSize: "750 x 1,050 mm",
      minSheetSize: "340 x 480 mm",
      printUnitsCount: 6,
      totalImpressions: 142.5,
      coatingUnit: "Coating unit with chamber blade system"
    },
    components: [
      { part: "Feeder Unit", newBaseline: "Dual-suction head, automatic pre-piling, non-stop grid", currentWear: "92% (Suction cups original, minor feed-gate wear)", status: "good", operationalHours: 18450 },
      { part: "Printing Units", newBaseline: "AutoPlate XL 2 cassette exchange, cylinder blanket auto wash", currentWear: "88% (Plate cylinder gripper tension inspected)", status: "good", operationalHours: 19100 },
      { part: "Dampening System", newBaseline: "Alcolor continuous dampening, alcohol-free stabilizer", currentWear: "72% (Water pan rollers require re-covering soon)", status: "warning", operationalHours: 17200 },
      { part: "Ink System", newBaseline: "Prinect Ink Fountain Keys, motorized blades, thermal control", currentWear: "95% (Ink fountain foils replaced, blades zero-level set)", status: "excellent", operationalHours: 19800 },
      { part: "Delivery Unit", newBaseline: "Preset Plus high-pile, dynamic sheet brakes, powder spray", currentWear: "85% (Brake bands replaced, grippers lubricated)", status: "good", operationalHours: 18900 },
      { part: "Electrical Cabinet", newBaseline: "Modular electronics, continuous filter fan, cooling exchanger", currentWear: "96% (Air filter cleaned, contacts verified)", status: "excellent", operationalHours: 19800 }
    ],
    health: [
      { category: "Mechanical Health", score: 88, grade: "A-", description: "All structural cylinder bearings run within manufacturer tolerances of < 3µm." },
      { category: "Electrical Health", score: 94, grade: "A", description: "Zero active bus fault warnings. Mains power supply harmonic distortions at 1.2%." },
      { category: "Cylinder Health", score: 85, grade: "B+", description: "Blanket and impression cylinders tested for true rotation. Minimal surface scuffs detected." },
      { category: "Print Registration Accuracy", score: 96, grade: "A", description: "Laser-guided paper control registration deviation under 0.05mm at max speed." },
      { category: "Safety Systems", score: 100, grade: "A+", description: "Emergency stops, light curtains, and guard interlocking sensors certified valid." },
      { category: "Documentation", score: 90, grade: "A", description: "Maintenance log complete with certified parts and lubrication schedules." }
    ],
    valuation: {
      originalValueUSD: 1650000,
      currentEstimatedValueUSD: 980000,
      depreciationRateAnnualPercent: 8.5
    }
  },
  "Speedmaster SM 74-4-H": {
    id: "HDB-SM74-4H-2013-312",
    specifications: {
      make: "Heidelberg",
      model: "Speedmaster SM 74-4-H",
      year: 2013,
      serialNumber: "HDB-SM74-0412B",
      weight: "18,400 kg",
      maxSpeed: "15,000 sheets/hr",
      maxSheetSize: "530 x 740 mm",
      minSheetSize: "210 x 280 mm",
      printUnitsCount: 4,
      totalImpressions: 265.2,
      coatingUnit: "Standard Delivery (No dedicated coater)"
    },
    components: [
      { part: "Feeder Unit", newBaseline: "Standard suction mechanism, touch-panel layout control", currentWear: "75% (Minor sheet separator brush wear, springs verified)", status: "good", operationalHours: 32400 },
      { part: "Printing Units", newBaseline: "AutoPlate auto-plate clamps, dampening roller stabilizer", currentWear: "68% (Gripper tips wear, mechanical play at limit)", status: "warning", operationalHours: 32400 },
      { part: "Dampening System", newBaseline: "Alcolor standard dampening, water replenishment auto-gauge", currentWear: "62% (Secondary pan roller needs replacement)", status: "warning", operationalHours: 32400 },
      { part: "Ink System", newBaseline: "CPC axial-center ink fountain, manual profile switches", currentWear: "81% (Rollers showing minor ink glazing, dynamic wash needed)", status: "good", operationalHours: 32400 },
      { part: "Delivery Unit", newBaseline: "High-pile classic design, dual-channel sheet powder spray", currentWear: "74% (Air blast nozzle partially clogged, cleaned on mock)", status: "good", operationalHours: 32400 },
      { part: "Electrical Cabinet", newBaseline: "Conventional solid-state relays, single heat exchange vent", currentWear: "88% (Power supplies healthy, cooling cabinet fan active)", status: "good", operationalHours: 32400 }
    ],
    health: [
      { category: "Mechanical Health", score: 71, grade: "C+", description: "Main gears have 0.08mm backlash. Play within acceptable limits but requires continuous audit." },
      { category: "Electrical Health", score: 82, grade: "B-", description: "Relay modules verified, cooling thermostat nominal, cabin temperatures normal." },
      { category: "Cylinder Health", score: 65, grade: "C", description: "Third unit blanket cylinder has light surface ding, repair compound applied." },
      { category: "Print Registration Accuracy", score: 78, grade: "C+", description: "Registration deviation ~0.12mm. Tolerable for standard job envelopes." },
      { category: "Safety Systems", score: 95, grade: "A", description: "Interlock relays active, cabin guard switches operate, light rails verified." },
      { category: "Documentation", score: 85, grade: "B", description: "Regular service reports on file, minor gaps in 2021 lubrication schedules." }
    ],
    valuation: {
      originalValueUSD: 820000,
      currentEstimatedValueUSD: 310000,
      depreciationRateAnnualPercent: 11.2
    }
  },
  "Speedmaster CX 102-5+L": {
    id: "HDB-CX102-5L-2021-994",
    specifications: {
      make: "Heidelberg",
      model: "Speedmaster CX 102-5+L",
      year: 2021,
      serialNumber: "HDB-CX102-3841A",
      weight: "38,200 kg",
      maxSpeed: "16,500 sheets/hr",
      maxSheetSize: "720 x 1,020 mm",
      minSheetSize: "340 x 480 mm",
      printUnitsCount: 5,
      totalImpressions: 58.4,
      coatingUnit: "Anilox chamber blade system with pump"
    },
    components: [
      { part: "Feeder Unit", newBaseline: "Preset vacuum belt board, acoustic double-sheet detector", currentWear: "97% (Factory original, vacuum belts tested)", status: "excellent", operationalHours: 6800 },
      { part: "Printing Units", newBaseline: "AutoPlate, modern pneumatic high-speed plate lock", currentWear: "95% (Perfect registration pin fitment, low hours)", status: "excellent", operationalHours: 6800 },
      { part: "Dampening System", newBaseline: "Alcolor continuous with Vario system, speed sync", currentWear: "93% (Roller surfaces in outstanding velvet state)", status: "excellent", operationalHours: 6800 },
      { part: "Ink System", newBaseline: "Color Assistant Pro software, ink profile auto-save", currentWear: "96% (Varnish free, keys clean and responsive)", status: "excellent", operationalHours: 6800 },
      { part: "Delivery Unit", newBaseline: "Preset Plus high capacity delivery, static electricity eliminator", currentWear: "94% (High capacity stacker tested, static bar at 100%)", status: "excellent", operationalHours: 6800 },
      { part: "Electrical Cabinet", newBaseline: "Can-bus fiber optic electronics, integrated central cold plate", currentWear: "98% (No dust ingression, fiber cables secure)", status: "excellent", operationalHours: 6800 }
    ],
    health: [
      { category: "Mechanical Health", score: 96, grade: "A", description: "Excellent bearings alignment. Roller oscillation levels within brand new factory thresholds." },
      { category: "Electrical Health", score: 98, grade: "A+", description: "Fiber-optic digital loops flawless. Air conditioning unit on electrical cabin running cold." },
      { category: "Cylinder Health", score: 95, grade: "A", description: "Zero scars. Micro-gauge tested blanket run-out under 2µm." },
      { category: "Print Registration Accuracy", score: 97, grade: "A+", description: "Prinect Link dynamic register error less than 0.03mm." },
      { category: "Safety Systems", score: 100, grade: "A+", description: "Laser security curtains calibrated and fully functional." },
      { category: "Documentation", score: 100, grade: "A+", description: "Full digital cloud ledger sync with active Heidelberg manufacturer subscription." }
    ],
    valuation: {
      originalValueUSD: 1420000,
      currentEstimatedValueUSD: 1120000,
      depreciationRateAnnualPercent: 7.2
    }
  }
};

// ==========================================
// SUB-COMPONENT: INTERACTIVE 360 ROTATOR (IMAGE SEQUENCE VECTOR SYSTEM)
// ==========================================
interface RotatorProps {
  getWalkaroundAngleLabel: (frame: number) => { label: string; detail: string };
}

function InteractiveRotator({ getWalkaroundAngleLabel }: RotatorProps) {
  const [frame, setFrame] = useState<number>(1);
  const totalFrames = 36;
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const startXRef = useRef<number>(0);
  const startFrameRef = useRef<number>(1);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    startXRef.current = e.clientX;
    startFrameRef.current = frame;
    if (containerRef.current) {
      containerRef.current.setPointerCapture(e.pointerId);
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const deltaX = e.clientX - startXRef.current;
    
    // Each 10 pixels of drag rotates 1 frame
    const deltaFrames = Math.round(deltaX / 10);
    let targetFrame = startFrameRef.current - deltaFrames;
    
    // Wrap around correctly (1 to 36)
    while (targetFrame < 1) targetFrame += totalFrames;
    while (targetFrame > totalFrames) targetFrame -= totalFrames;
    
    setFrame(targetFrame);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    if (containerRef.current) {
      containerRef.current.releasePointerCapture(e.pointerId);
    }
  };

  const angleLabelObj = getWalkaroundAngleLabel(frame);
  const angleRotation = (frame * 10) % 360;

  return (
    <div className="flex-1 w-full flex flex-col justify-between p-6 bg-[#0f121d] select-none h-full relative">
      <div className="flex items-center justify-between z-10 text-white">
        <div>
          <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block">ANGLE INDEX</span>
          <span className="text-sm font-bold font-mono">
            {angleRotation}° <span className="text-slate-500">({frame}/36 frames)</span>
          </span>
        </div>
        <div className="text-right">
          <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block">VISIBLE REGION</span>
          <span className="text-xs font-bold text-blue-400">
            {angleLabelObj.label}
          </span>
        </div>
      </div>

      {/* Printing Press Layout Render via SVG Elements */}
      <div 
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="flex-1 flex items-center justify-center cursor-ew-resize relative outline-none py-4"
      >
        <div className="absolute inset-0 bg-radial-gradient from-blue-900/15 to-transparent opacity-60 pointer-events-none" />
        
        <div className="w-full max-w-[480px]">
          <svg viewBox="0 0 500 240" className="w-full h-auto transition-transform duration-100" style={{ transform: `rotateY(${angleRotation * 0.15}deg)` }}>
            {/* Floor depth Shadow */}
            <ellipse cx="250" cy="210" rx="210" ry="15" fill="#000" fillOpacity="0.25" />
            
            {/* Common Industrial base frame */}
            <rect x="60" y="160" width="380" height="40" rx="4" fill="#1e293b" stroke="#334155" strokeWidth="2" />
            <line x1="60" y1="180" x2="440" y2="180" stroke="#0f172a" strokeWidth="3" />
            
            {/* FEEDER UNIT (On left side of sheetfed press) */}
            <g style={{ transform: `translateX(${Math.sin((angleRotation * Math.PI) / 180) * 8}px)` }}>
              <rect x="65" y="80" width="60" height="80" rx="2" fill="#334155" stroke="#475569" strokeWidth="1.5" />
              <rect x="75" y="100" width="40" height="50" fill="#cbd5e1" />
              <path d="M 95 80 L 95 65 L 115 65" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" />
              <circle cx="115" cy="65" r="4" fill="#3b82f6" />
            </g>

            {/* INTEGRATED PRINTING BLANKET CYLINDER MODULES */}
            <g style={{ transform: `translateX(${Math.cos((angleRotation * Math.PI) / 180) * 5}px)` }}>
              {/* Printing deck 1 */}
              <rect x="135" y="50" width="55" height="110" rx="3" fill="#2d3748" stroke="#4a5568" strokeWidth="2" />
              <circle cx="162.5" cy="85" r="16" fill="#1b222d" stroke="#f43f5e" strokeWidth="2" />
              <circle cx="162.5" cy="115" r="14" fill="#1b222d" stroke="#cbd5e1" strokeWidth="1.5" />
              
              {/* Printing deck 2 */}
              <rect x="195" y="50" width="55" height="110" rx="3" fill="#2d3748" stroke="#4a5568" strokeWidth="2" />
              <circle cx="222.5" cy="85" r="16" fill="#1b222d" stroke="#ec4899" strokeWidth="2" />
              <circle cx="222.5" cy="115" r="14" fill="#1b222d" stroke="#cbd5e1" strokeWidth="1.5" />
              
              {/* Printing deck 3 */}
              <rect x="255" y="50" width="55" height="110" rx="3" fill="#2d3748" stroke="#4a5568" strokeWidth="2" />
              <circle cx="282.5" cy="85" r="16" fill="#1b222d" stroke="#eab308" strokeWidth="2" />
              <circle cx="282.5" cy="115" r="14" fill="#1b222d" stroke="#cbd5e1" strokeWidth="1.5" />

              {/* Printing deck 4 */}
              <rect x="315" y="50" width="55" height="110" rx="3" fill="#2d3748" stroke="#4a5568" strokeWidth="2" />
              <circle cx="342.5" cy="85" r="16" fill="#1b222d" stroke="#06b6d4" strokeWidth="2" />
              <circle cx="342.5" cy="115" r="14" fill="#1b222d" stroke="#cbd5e1" strokeWidth="1.5" />
            </g>

            {/* DELIVERY MODULE STACK */}
            <g style={{ transform: `translateX(${-Math.sin((angleRotation * Math.PI) / 180) * 8}px)` }}>
              <rect x="380" y="70" width="55" height="90" rx="2" fill="#334155" stroke="#475569" strokeWidth="1.5" />
              <rect x="385" y="105" width="45" height="40" fill="#f8fafc" />
              <circle cx="395" cy="90" r="5" fill="#475569" />
              <circle cx="410" cy="90" r="5" fill="#475569" />
            </g>
            
            {/* Sheetfed paper transit lines */}
            <path d="M 125 140 Q 162.5 150 195 140 T 315 140 T 380 145" fill="none" stroke="#60a5fa" strokeWidth="1.5" strokeDasharray="3 3" />
          </svg>
        </div>

        {isDragging && (
          <div className="absolute inset-x-0 bottom-4 flex justify-center pointer-events-none">
            <span className="text-[9px] font-bold text-white/40 bg-slate-900/80 px-2 py-0.5 rounded font-mono uppercase tracking-widest animate-pulse border border-white/5">
              Swelling Rotation Orbit
            </span>
          </div>
        )}
      </div>

      <div className="bg-slate-900/60 p-3.5 rounded-xl border border-white/5 text-[11px] text-slate-400 min-h-[50px] flex items-center gap-3">
        <RotateCcw size={14} className="text-cyan-400 shrink-0 animate-spin-slow" />
        <div>
          <strong className="text-slate-200">{angleLabelObj.label}:</strong> {angleLabelObj.detail}
        </div>
      </div>
    </div>
  );
}

// ==========================================
// SUB-COMPONENT: EXPLODED SCHEMATIC VIEW
// ==========================================
interface ExplodedProps {
  activeMachinePreset: MachineTwinData;
  activeInspectionPart: string;
  setActiveInspectionPart: (part: string) => void;
}

function ExplodedSchematicView({ activeMachinePreset, activeInspectionPart, setActiveInspectionPart }: ExplodedProps) {
  const [isExploded, setIsExploded] = useState<boolean>(true);

  // Heidelberg units modular blocks mapping
  const printDecksBlocks = [
    { name: "Feeder Unit", color: "from-sky-500 to-blue-600", border: "border-blue-400", x: -160, y: -20, size: "w-28 h-20" },
    { name: "Printing Units", color: "from-indigo-500 to-indigo-600", border: "border-indigo-400", x: -40, y: -60, size: "w-32 h-24" },
    { name: "Dampening System", color: "from-cyan-500 to-teal-600", border: "border-teal-400", x: 40, y: 70, size: "w-24 h-16" },
    { name: "Ink System", color: "from-fuchsia-500 to-purple-600", border: "border-purple-400", x: -90, y: 60, size: "w-24 h-16" },
    { name: "Delivery Unit", color: "from-slate-600 to-slate-700", border: "border-slate-500", x: 150, y: -20, size: "w-28 h-20" },
    { name: "Electrical Cabinet", color: "from-amber-600 to-yellow-600", border: "border-yellow-400", x: 60, y: -30, size: "w-20 h-28" }
  ];

  const currentDiagnoseInfo = activeMachinePreset.components.find(c => c.part === activeInspectionPart);

  return (
    <div className="flex-1 w-full flex flex-col justify-between p-6 bg-[#0c0e17] h-full">
      <div className="flex items-center justify-between shrink-0 mb-4 z-10 text-white">
        <div>
          <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block">DIAGNOSTIC MAP</span>
          <span className="text-xs text-slate-300">Click a deck node to inspect local condition diagnostics.</span>
        </div>

        <button 
          onClick={() => setIsExploded(!isExploded)}
          className={`text-[10px] font-bold px-3 py-1.5 rounded-lg border transition-all ${
            isExploded 
              ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30 shadow-inner' 
              : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
          }`}
        >
          {isExploded ? 'Consolidate Layout' : 'Explode Schematic Decks'}
        </button>
      </div>

      <div className="flex-1 relative flex items-center justify-center overflow-hidden min-h-[220px]">
        {/* Schematic matrix blueprint background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#3b82f605_1px,transparent_1px),linear-gradient(to_bottom,#3b82f605_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />
        
        {isExploded && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
            <line x1="120" y1="110" x2="380" y2="110" stroke="#4f46e5" strokeWidth="1" strokeDasharray="4 4" className="opacity-40" />
            <line x1="250" y1="40" x2="250" y2="180" stroke="#06b6d4" strokeWidth="1" strokeDasharray="4 4" className="opacity-40" />
          </svg>
        )}

        <div className="relative w-full h-full flex items-center justify-center">
          {printDecksBlocks.map((block) => {
            const isSelected = activeInspectionPart === block.name;
            return (
              <motion.button
                key={block.name}
                onClick={() => setActiveInspectionPart(block.name)}
                animate={{ 
                  x: isExploded ? block.x : 0, 
                  y: isExploded ? block.y : 0,
                  scale: isSelected ? 1.05 : 1
                }}
                transition={{ type: "spring", stiffness: 120, damping: 14 }}
                className={`absolute ${block.size} p-2.5 rounded-xl border flex flex-col justify-between text-left cursor-pointer select-none transition-shadow ${
                  isSelected 
                    ? "bg-gradient-to-br " + block.color + " text-white border-white shadow-[0_0_20px_rgba(59,130,246,0.3)] z-30 font-bold" 
                    : "bg-slate-900/90 text-slate-300 " + block.border + " border-white/10 hover:bg-slate-800 z-20 hover:border-white/30"
                }`}
              >
                <div className="flex justify-between items-start w-full">
                  <span className="text-[9px] uppercase font-bold tracking-wider opacity-85 leading-none">
                    {block.name.split(" ")[0]}
                  </span>
                  {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />}
                </div>

                <div className="text-[11px] font-black tracking-tight leading-snug break-words">
                  {block.name}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {currentDiagnoseInfo && (
        <div className="bg-slate-900 border border-white/5 p-3.5 rounded-xl text-xs text-slate-300 mt-4 flex flex-col md:flex-row md:items-center justify-between gap-3 shrink-0">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest font-mono block">
              Node wear: {currentDiagnoseInfo.part}
            </span>
            <p className="text-slate-200">
              {currentDiagnoseInfo.currentWear}
            </p>
          </div>
          
          <div className="flex items-center gap-3 shrink-0 border-t md:border-t-0 md:border-l border-white/10 pt-2 md:pt-0 md:pl-4">
            <div>
              <span className="text-[9px] font-bold text-slate-400 block font-mono">INS_STATUS</span>
              <span className={`font-bold capitalize ${
                currentDiagnoseInfo.status === 'excellent' ? 'text-emerald-400' :
                currentDiagnoseInfo.status === 'good' ? 'text-blue-400' :
                currentDiagnoseInfo.status === 'warning' ? 'text-amber-400' : 'text-rose-400'
              }`}>
                ● {currentDiagnoseInfo.status}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ==========================================
// MAIN REUSABLE TWIN MODULE COMPONENT
// ==========================================
export function DigitalMachineTwin() {
  const [selectedModel, setSelectedModel] = useState<string>("Speedmaster XL 106-6+L");
  const [activeTab, setActiveTab] = useState<"viewer" | "exploded" | "architecture">("viewer");
  
  const [customImpressions, setCustomImpressions] = useState<number>(142.5);
  const [customHealthAdjustment, setCustomHealthAdjustment] = useState<number>(0); 
  const [showQrModal, setShowQrModal] = useState<boolean>(false);
  const [showPassportModal, setShowPassportModal] = useState<boolean>(false);
  const [showListingModal, setShowListingModal] = useState<boolean>(false);
  const [copiedText, setCopiedText] = useState<boolean>(false);
  const [activeInspectionPart, setActiveInspectionPart] = useState<string>("Printing Units");

  const activeMachinePreset = HEIDELBERG_PRESETS[selectedModel];

  useEffect(() => {
    setCustomImpressions(activeMachinePreset.specifications.totalImpressions);
    setCustomHealthAdjustment(0);
  }, [selectedModel]);

  // Dynamic asset calculation matching requested commercial schema goals
  const calculateLiveValuation = () => {
    const orig = activeMachinePreset.valuation.originalValueUSD;
    const year = activeMachinePreset.specifications.year;
    const currentYear = 2026;
    const age = Math.max(1, currentYear - year);
    const depRate = activeMachinePreset.valuation.depreciationRateAnnualPercent / 100;
    
    // Impact of prints impressions logged
    const impImpact = Math.max(0.65, 1 - (customImpressions / 600)); 
    
    // Impact of health modifications
    const baseHealth = activeMachinePreset.health.reduce((acc, curr) => acc + curr.score, 0) / activeMachinePreset.health.length;
    const computedHealth = Math.min(100, Math.max(30, baseHealth + customHealthAdjustment));
    const healthImpact = computedHealth / 90;

    const estimatedValue = orig * Math.pow(1 - depRate, age) * impImpact * healthImpact;
    
    return {
      value: Math.round(Math.max(orig * 0.12, estimatedValue)),
      healthScore: Math.round(computedHealth),
      ageYears: age,
      overallGrade: computedHealth >= 95 ? "A+" : computedHealth >= 90 ? "A" : computedHealth >= 85 ? "A-" : computedHealth >= 80 ? "B+" : computedHealth >= 70 ? "B" : computedHealth >= 60 ? "C" : "D"
    };
  };

  const calculatedResult = calculateLiveValuation();

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const generateMarketplaceListing = () => {
    const specs = activeMachinePreset.specifications;
    return `### 🔥 FOR SALE: Heidelberg ${specs.model} Offset Printing Press
**Year of Manufacture:** ${specs.year}
**Serial Number:** ${specs.serialNumber}
**Format:** ${specs.maxSheetSize} mm (Max Sheet Size)
**Impressions Logged:** ${customImpressions.toFixed(1)} Million sheets
**Configuration:** ${specs.printUnitsCount} Printing Units with ${specs.coatingUnit}

#### 📋 Technical Specifications
- **Max Production Speed:** ${specs.maxSpeed}
- **Machine Total Weight:** ${specs.weight}
- **Minimum Sheet Dimensions:** ${specs.minSheetSize}

#### 🛠️ Current Inspection Summary
- **Overall Operational Grade:** ${calculatedResult.overallGrade} (${calculatedResult.healthScore}% health index)
- **Top Conditions:** Electrical Cabinet is at pristine levels. All cylinders tested for true rotation alignment.
- **Estimated Machinery Exchange Value:** $${calculatedResult.value.toLocaleString()} USD (Ex-Works options available)

*Verified by AVG VERIFIED Command Center Digital Twin Service. Interlocked Passport ID: ${activeMachinePreset.id}.*`;
  };

  const getWalkaroundAngleLabel = (angleFrame: number) => {
    const degrees = Math.round((angleFrame / 36) * 360);
    if (degrees <= 45 || degrees >= 315) return { label: "Heidelberg Feeder Unit", detail: "Suction head nozzles, double-sheet guard detectors, dynamic timing feed bars." };
    if (degrees > 45 && degrees <= 135) return { label: "Printing Units Platform", detail: "Inking keys console, AutoPlate modern cassette lock, true-aligned blankets." };
    if (degrees > 135 && degrees <= 225) return { label: "Preset Plus Delivery", detail: "Integrated anti-static electric bar, high-pile dynamic brake grips, powder nozzle." };
    return { label: "Heidelberg Electrical Cabinet", detail: "Modular backup contacts, continuous cooling exchanger vents, server logic link." };
  };

  return (
    <div className="max-w-7xl mx-auto pb-20">
      
      {/* HEADER BANNER */}
      <div className="mb-8 flex flex-col xl:flex-row xl:items-center justify-between gap-6 bg-slate-900 text-white p-6 md:p-8 rounded-3xl border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-slate-900/10 pointer-events-none" />
        <div className="absolute top-0 inset-x-0 h-1 flex">
          <div className="flex-1 bg-cyan-400"></div>
          <div className="flex-1 bg-pink-500"></div>
          <div className="flex-1 bg-yellow-400"></div>
          <div className="flex-1 bg-slate-950"></div>
        </div>

        <div className="relative z-10 space-y-2">
          <div className="flex flex-wrap items-center gap-3">
            <span className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider border border-blue-400/20 flex items-center gap-1.5">
              <Printer size={12} /> Heidelberg Offset Press
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-black/40 px-2 py-0.5 rounded border border-slate-800">
              LEDGER_ID: {activeMachinePreset.id}
            </span>
          </div>
          
          <h1 className="text-2xl md:text-3.5xl font-black text-white tracking-tight">
            Heidelberg <span className="text-blue-400 font-medium">{activeMachinePreset.specifications.model}</span>
          </h1>
          
          <p className="text-slate-300 text-sm max-w-2xl font-normal leading-relaxed">
            Authorized Digital Twin interface representing true mechanical specifications, wear analytics, and dynamic asset passport ledger. 
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap gap-2.5">
          <button 
            onClick={() => setShowPassportModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 hover:border-slate-600 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
          >
            <FileText size={14} className="text-blue-400" />
            Machine Passport
          </button>
          
          <button 
            onClick={() => setShowQrModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 hover:border-slate-600 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
          >
            <QrCode size={14} className="text-cyan-400" />
            QR Code System
          </button>
          
          <button 
            onClick={() => setShowListingModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
          >
            <Sparkles size={14} className="text-amber-300" />
            Marketplace Draft
          </button>
        </div>
      </div>

      {/* MODEL SELECTOR & ADJUSTMENT SLIDERS */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 mb-8">
        <div className="xl:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <label className="text-xs uppercase font-bold text-slate-500 tracking-wider block mb-2 font-mono">Select Machinery Model</label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {Object.keys(HEIDELBERG_PRESETS).map((key) => {
                const isSelected = selectedModel === key;
                return (
                  <button
                    key={key}
                    onClick={() => setSelectedModel(key)}
                    className={`p-3 text-left rounded-xl border text-xs font-semibold transition-all flex flex-col justify-between h-20 cursor-pointer ${
                      isSelected 
                        ? "bg-slate-900 text-white border-slate-900 shadow-md" 
                        : "bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                    }`}
                  >
                    <span className="opacity-95 leading-tight">{key}</span>
                    <span className={`text-[9px] font-mono ${isSelected ? "text-blue-300" : "text-slate-400"}`}>
                      {HEIDELBERG_PRESETS[key].specifications.year} · {HEIDELBERG_PRESETS[key].specifications.printUnitsCount} Colors
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
            <span>Manufacturer: <strong className="text-slate-800">Germany (Heidelberg)</strong></span>
            <span>Technology: <strong className="text-slate-800">Continuous Offset</strong></span>
          </div>
        </div>

        {/* Dynamic Calibration Controls */}
        <div className="xl:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase font-bold text-slate-500 tracking-wider">Calibration Sandbox</span>
              <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 flex items-center gap-1">
                Calibration Sandbox Active
              </span>
            </div>

            {/* Slider 1: Total Impressions */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-600 font-medium">Total Impressions Count:</span>
                <span className="font-bold text-slate-800">{customImpressions.toFixed(1)} Million sheets</span>
              </div>
              <input 
                type="range"
                min="5"
                max="500"
                step="5"
                value={customImpressions}
                onChange={(e) => setCustomImpressions(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>5M</span>
                <span>250M</span>
                <span>500M (End of lifespan)</span>
              </div>
            </div>

            {/* Slider 2: Wear Health Offset */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-600 font-medium">Fine-tune Condition Modifier:</span>
                <span className={`font-bold ${customHealthAdjustment >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                  {customHealthAdjustment >= 0 ? `+${customHealthAdjustment}` : customHealthAdjustment}% Wear Adjustment
                </span>
              </div>
              <input 
                type="range"
                min="-30"
                max="10"
                value={customHealthAdjustment}
                onChange={(e) => setCustomHealthAdjustment(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>Severe Scoring (-30%)</span>
                <span>Normal Calibration (0)</span>
                <span>Freshly Serviced (+10%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* MAIN VISUAL WORKSPACE AND TABS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 flex flex-col gap-6">
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm flex flex-col h-[520px]">
            <div className="px-6 py-4.5 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-bold text-slate-800 text-base">Press Visualizers</h2>
                <p className="text-[11px] text-slate-500">Continuous laser alignment vectors</p>
              </div>

              <div className="flex items-center gap-1.5 bg-white border border-slate-200 p-1 rounded-xl shadow-xs">
                <button
                  onClick={() => setActiveTab("viewer")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === "viewer"
                      ? "bg-blue-600 text-white shadow-sm"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Maximize2 size={12} className="inline mr-1" />
                  360° Walkaround
                </button>
                <button
                  onClick={() => setActiveTab("exploded")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === "exploded"
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Layers size={12} className="inline mr-1" />
                  Exploded Schematics
                </button>
                <button
                  onClick={() => setActiveTab("architecture")}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    activeTab === "architecture"
                      ? "bg-slate-800 text-white shadow-sm"
                      : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Settings2 size={12} className="inline mr-1" />
                  Assets & Integration Info
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-hidden relative bg-[#0f121d]">
              <AnimatePresence mode="wait">
                {activeTab === "viewer" && (
                  <motion.div
                    key="viewer"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="absolute inset-0 flex flex-col"
                  >
                    <InteractiveRotator getWalkaroundAngleLabel={getWalkaroundAngleLabel} />
                  </motion.div>
                )}

                {activeTab === "exploded" && (
                  <motion.div
                    key="exploded"
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="absolute inset-0 flex flex-col"
                  >
                    <ExplodedSchematicView 
                      activeMachinePreset={activeMachinePreset}
                      activeInspectionPart={activeInspectionPart}
                      setActiveInspectionPart={setActiveInspectionPart}
                    />
                  </motion.div>
                )}

                {activeTab === "architecture" && (
                  <motion.div
                    key="architecture"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 overflow-y-auto p-6 text-slate-300 flex flex-col justify-between"
                  >
                    <div className="space-y-5">
                      <h3 className="text-white font-bold text-lg flex items-center gap-2">
                        <Package size={18} className="text-cyan-400" /> Digital Twin Systems Management
                      </h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        <div className="bg-slate-900/60 p-4 rounded-xl border border-white/5 space-y-2">
                          <h4 className="font-bold text-blue-300">1. Image Asset Sequence Management</h4>
                          <p className="text-slate-400 leading-relaxed">
                            Machinery frames are shot at precise 10° intervals rotating on a turntables. Standardized files are labeled `FRAME_01.jpg` to `FRAME_36.jpg` and stored in Cloud Storage matching:
                          </p>
                          <code className="text-cyan-300 block bg-black/50 p-1.5 rounded font-mono text-[10px]">
                            gs://avg-equipment-twins/Heidelberg/{activeMachinePreset.specifications.model.replace(/\+/g, "%2B")}/frame_##.jpg
                          </code>
                        </div>

                        <div className="bg-slate-900/60 p-4 rounded-xl border border-white/5 space-y-2">
                          <h4 className="font-bold text-teal-300">2. Cloud Specification Schema</h4>
                          <p className="text-slate-400 leading-relaxed">
                            All configurations, factory baselines and custom thresholds load directly from Firestore. This module connects to:
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px]">
                            <li><strong>/databases/(default)/documents/twins/</strong></li>
                            <li><strong>/databases/(default)/documents/registrations/</strong></li>
                          </ul>
                        </div>

                        <div className="bg-slate-900/60 p-4 rounded-xl border border-white/5 space-y-2">
                          <h4 className="font-bold text-purple-300">3. Interoperable Subsystems Core</h4>
                          <p className="text-slate-400 leading-relaxed">
                            Once approved, this standalone module can immediately resolve document references from:
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-slate-300 font-mono text-[10px]">
                            <li><strong>Machine Passport:</strong> UUID Ledger bindings</li>
                            <li><strong>AI Valuation:</strong> Multi-point grade indices</li>
                            <li><strong>QR System:</strong> Serialized routing params</li>
                          </ul>
                        </div>

                        <div className="bg-slate-900/60 p-4 rounded-xl border border-white/5 space-y-2">
                          <h4 className="font-bold text-amber-300">4. Dynamic State Sync</h4>
                          <p className="text-slate-400 leading-relaxed">
                            Replacing active real-time telemetry with point-inspection updates enables reliable, bulletproof evaluations safe from stream disconnects or network failures.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 pt-4 border-t border-white/5 flex justify-between items-center text-[11px] text-slate-500">
                      <span>V2.4.0 Schema Standard Compliant</span>
                      <span className="text-cyan-400 flex items-center gap-1 cursor-pointer hover:underline" onClick={() => setActiveTab("viewer")}>
                        Back to Walkaround <ArrowRight size={12} />
                      </span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Right Column: Health Score Metrics */}
        <div className="lg:col-span-1 flex flex-col gap-6">
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm flex flex-col justify-between h-[520px]">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-bold text-slate-800 flex items-center gap-2">
                  <Activity size={17} className="text-emerald-500 animate-pulse" />
                  Printing Health Indices
                </h3>
                <span className="text-[10px] font-bold text-slate-500 uppercase bg-slate-100 px-2 py-0.5 rounded border">
                  Inspection Grade
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Calibrated against target thresholds & current impressions
              </p>
            </div>

            <div className="p-5 flex-1 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between bg-slate-50 p-4 rounded-2xl border border-slate-100 shadow-inner">
                <div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Aggregate Score</div>
                  <div className="text-4xl font-black text-slate-900">{calculatedResult.healthScore}%</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Valuation Model</div>
                  <div className="text-lg font-bold text-emerald-600">Grade {calculatedResult.overallGrade}</div>
                </div>
              </div>

              <div className="space-y-3.5">
                {activeMachinePreset.health.map((item, idx) => {
                  const rawScore = item.score + customHealthAdjustment;
                  const score = Math.min(100, Math.max(30, rawScore));
                  const itemGrade = score >= 95 ? "A+" : score >= 100 ? "A+" : score >= 90 ? "A" : score >= 85 ? "A-" : score >= 80 ? "B+" : score >= 70 ? "B" : score >= 60 ? "C" : "D";
                  
                  return (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-semibold text-slate-700">{item.category}</span>
                        <span className="font-bold text-slate-900">{itemGrade} <span className="text-slate-400 font-normal">({score}%)</span></span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          style={{ width: `${score}%` }}
                          className={`h-full rounded-full transition-all duration-300 ${
                            score >= 90 
                              ? "bg-emerald-500" 
                              : score >= 80 
                                ? "bg-blue-500" 
                                : score >= 65 
                                  ? "bg-amber-500" 
                                  : "bg-rose-500"
                          }`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-4 bg-slate-900 text-white rounded-b-3xl">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <TrendingUp size={12} className="text-blue-400" /> Dynamic Value (USD):
                </span>
                <span className="font-bold text-emerald-400 text-sm">
                  ${calculatedResult.value.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM SEGMENTS (SPECS, WEAR DIAGNOSTICS) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
        
        {/* Specifications Panel */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col h-full lg:col-span-1">
          <div className="p-4.5 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Settings2 size={16} className="text-slate-500" />
              Machine Specifications
            </h3>
            <span className="text-[10px] font-mono text-slate-400 bg-slate-200/50 px-2 py-0.5 rounded">
              {activeMachinePreset.specifications.year} model
            </span>
          </div>
          
          <div className="p-4 flex-1">
            <div className="space-y-0.5 max-h-[340px] overflow-y-auto pr-1">
              {Object.entries(activeMachinePreset.specifications).map(([key, value]) => {
                if (key === 'totalImpressions') {
                  return (
                    <div key={key} className="flex justify-between py-2.5 border-b border-slate-100 hover:bg-slate-50 px-2 rounded transition-colors text-xs">
                      <span className="text-slate-500 font-medium capitalize">Impressions (Customized)</span>
                      <span className="font-semibold text-blue-600">{customImpressions.toFixed(1)} Million</span>
                    </div>
                  );
                }
                return (
                  <div key={key} className="flex justify-between py-2.5 border-b border-slate-100 hover:bg-slate-50 px-2 rounded transition-colors text-xs">
                    <span className="text-slate-500 font-medium capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </span>
                    <span className="font-semibold text-slate-800 text-right truncate max-w-[200px]">{value}</span>
                  </div>
                );
              })}
            </div>
            
            <button
              onClick={() => handleCopy(JSON.stringify(activeMachinePreset, null, 2))}
              className="mt-4 w-full flex items-center justify-center gap-2 py-2 bg-slate-100 hover:bg-slate-200/80 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              <Copy size={13} /> {copiedText ? "Copied Spec JSON!" : "Copy Full Schema Schema"}
            </button>
          </div>
        </div>

        {/* Condition Baseline: New vs. Current (Used) */}
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col lg:col-span-2">
          <div className="p-4.5 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <ArrowRight size={16} className="text-purple-500" />
              Wear Diagnostics: New vs. Used Breakdown
            </h3>
            <span className="text-[10px] text-slate-500 font-semibold bg-white border px-2 py-0.5 rounded shadow-xs">
              Factory Tolerances vs. Field Wear
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/50 text-[10px] uppercase font-bold tracking-wider text-slate-500 border-b border-slate-200">
                  <th className="p-3 w-1/4">Modular Unit</th>
                  <th className="p-3 w-5/12 border-l border-slate-100">Factory Standard (New)</th>
                  <th className="p-3 w-1/3 border-l border-slate-100">Physical Inspection (Used)</th>
                </tr>
              </thead>
              <tbody className="text-xs">
                {activeMachinePreset.components.map((row, idx) => {
                  return (
                    <tr key={idx} className="border-b border-slate-100 hover:bg-slate-50/50 transition-colors">
                      <td className="p-3 font-semibold text-slate-800">{row.part}</td>
                      <td className="p-3 text-slate-500 leading-normal border-l border-slate-100 bg-slate-50/20">{row.newBaseline}</td>
                      <td className="p-3 border-l border-slate-100 flex items-start gap-2">
                        {row.status === 'excellent' && <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />}
                        {row.status === 'good' && <span className="w-2 h-2 rounded-full bg-blue-500 mt-1.5 shrink-0" />}
                        {row.status === 'warning' && <span className="w-2 h-2 rounded-full bg-amber-500 mt-1.5 shrink-0 animate-pulse" />}
                        <span className={row.status === 'warning' ? 'text-amber-800 font-medium' : 'text-slate-700'}>
                          {row.currentWear}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ==========================================
          MODALS FOR DIGITAL TWIN VERIFICATIONS
         ========================================== */}
      
      {/* 1. MACHINE PASSPORT POPUP */}
      <AnimatePresence>
        {showPassportModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPassportModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />
            
            <motion.div 
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              className="bg-white rounded-3xl overflow-hidden max-w-2xl w-full border border-slate-200 shadow-2xl relative z-10 flex flex-col max-h-[90vh]"
            >
              <div className="bg-slate-950 p-6 text-white border-b border-amber-500/30 relative">
                <div className="absolute top-0 right-0 w-32 h-full bg-gradient-to-l from-amber-500/10 to-transparent pointer-events-none" />
                <h3 className="text-xl font-black text-amber-400 tracking-tight flex items-center gap-2">
                  <FileText size={20} /> Verified Asset Passport Certificate
                </h3>
                <p className="text-slate-400 text-xs mt-1">
                  Cryptographically Bound Machine Ledger · AVG VERIFIED STANDARD
                </p>
              </div>

              <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700">
                <div className="border border-slate-100 bg-slate-50 p-4 rounded-2xl flex flex-wrap justify-between gap-4">
                  <div>
                    <span className="text-slate-400 font-bold block uppercase text-[9px] tracking-wider">PASSPORT UUID</span>
                    <span className="font-mono font-bold text-slate-800">{activeMachinePreset.id}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block uppercase text-[9px] tracking-wider">ISSUED DATE</span>
                    <span className="font-medium text-slate-800">2026-06-16</span>
                  </div>
                  <div>
                    <span className="text-slate-400 font-bold block uppercase text-[9px] tracking-wider">VALUATION MATCH</span>
                    <span className="font-bold text-emerald-600">${calculatedResult.value.toLocaleString()} USD</span>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-extrabold text-slate-900 uppercase tracking-wide text-[10px] text-blue-600">Interlinked Smart Contract Properties</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-slate-50/50 rounded-xl border border-slate-100">
                      <span className="text-slate-400 block font-medium">Ownership Verification</span>
                      <span className="font-semibold text-slate-800">AVG verified registered trust ledger</span>
                    </div>
                    <div className="p-3 bg-slate-50/50 rounded-xl border border-slate-100">
                      <span className="text-slate-400 block font-medium">History Log Integrity</span>
                      <span className="font-semibold text-slate-800">100% complete digital log matching specs</span>
                    </div>
                    <div className="p-3 bg-slate-50/50 rounded-xl border border-slate-100">
                      <span className="text-slate-400 block font-medium">Cylinder Accuracy Verification</span>
                      <span className="font-semibold text-emerald-600 font-mono">PASSED ISO:12647 spectral criteria</span>
                    </div>
                    <div className="p-3 bg-slate-50/50 rounded-xl border border-slate-100">
                      <span className="text-slate-400 block font-medium">Telemetry Connection Ready</span>
                      <span className="font-mono text-slate-850 text-[10px]">avg-api.verified/v2/twins/{activeMachinePreset.id}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-amber-800 leading-relaxed text-[11px]">
                  <strong>🔒 Note on Blockchain Integration:</strong> This Passport is designed to render an immutable machine status audit for import/export machinery shipping declarations, providing complete clarity for international offsets press transactions.
                </div>
              </div>

              <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
                <button 
                  onClick={() => handleCopy(JSON.stringify(activeMachinePreset, null, 2))}
                  className="px-4 py-2 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-bold transition-all cursor-pointer"
                >
                  Copy Cryptographic Specs JSON
                </button>
                <button 
                  onClick={() => setShowPassportModal(false)}
                  className="px-5 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800 transition-all cursor-pointer"
                >
                  Close Certificate
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. QR CODE SYSTEM POPUP */}
      <AnimatePresence>
        {showQrModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowQrModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />
            
            <motion.div 
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              className="bg-white rounded-3xl overflow-hidden max-w-md w-full border border-slate-200 shadow-2xl relative z-10 p-6 text-center space-y-6"
            >
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-600 bg-cyan-50 px-3 py-1 rounded-full border border-cyan-100 inline-block">
                  Serialized Endpoint System
                </span>
                <h3 className="text-xl font-black text-slate-900">Scan & Bind Machine Portal</h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  Locate decals on the side of the main electrical cabinet to sync physical measurements.
                </p>
              </div>

              <div className="bg-slate-100/50 p-6 rounded-2xl flex flex-col items-center justify-center relative border border-slate-200/50">
                <div className="bg-white p-4.5 rounded-xl border border-slate-200 shadow-inner flex flex-col items-center gap-2">
                  <div className="w-40 h-40 bg-slate-950 p-2 text-white flex flex-col items-center justify-center font-mono text-[10px] font-bold rounded-lg relative overflow-hidden">
                    <div className="grid grid-cols-4 gap-1.5 w-full h-full opacity-80">
                      <div className="bg-white rounded p-1 flex items-center justify-center text-slate-950">
                        <QrCode size={40} />
                      </div>
                      <div className="bg-blue-400 rounded"></div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-white rounded flex items-center justify-center text-slate-950">
                        <QrCode size={40} />
                      </div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-indigo-400 rounded"></div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-cyan-400 rounded"></div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-white rounded flex items-center justify-center text-slate-950">
                        <QrCode size={40} />
                      </div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-white rounded"></div>
                      <div className="bg-emerald-400 rounded"></div>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 font-bold">{activeMachinePreset.id}</span>
                </div>
              </div>

              <p className="text-xs text-slate-500 leading-normal max-w-sm mx-auto">
                Scanning this QR redirects inspectors to the active mobile-view sequence, rendering instant cylinder wear check sheets.
              </p>

              <div className="flex gap-2">
                <button
                  onClick={() => handleCopy(`https://avg-exchange.hub/twin/${activeMachinePreset.id}`)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200/80 text-slate-700 text-xs font-bold rounded-lg transition-all cursor-pointer"
                >
                  Copy Portal URL
                </button>
                <button
                  onClick={() => setShowQrModal(false)}
                  className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-all cursor-pointer"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. MARKETPLACE LISTING POPUP */}
      <AnimatePresence>
        {showListingModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowListingModal(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs"
            />
            
            <motion.div 
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              className="bg-white rounded-3xl overflow-hidden max-w-2xl w-full border border-slate-200 shadow-2xl relative z-10 flex flex-col max-h-[90vh]"
            >
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6 text-white text-left">
                <h3 className="text-lg font-black tracking-tight flex items-center gap-2">
                  <Sparkles size={18} /> Machinery Listing Exporter Template
                </h3>
                <p className="text-blue-100 text-xs mt-0.5">
                  Formatted specifically for PressDepot & Machinio marketplaces
                </p>
              </div>

              <div className="p-6 overflow-y-auto flex-1 bg-slate-50">
                <div className="text-xs font-mono text-slate-700 bg-white p-5 rounded-xl border border-slate-200 whitespace-pre-wrap select-text max-h-[360px] overflow-y-auto leading-relaxed">
                  {generateMarketplaceListing()}
                </div>
              </div>

              <div className="p-4 bg-white border-t border-slate-100 flex justify-between items-center">
                <span className="text-xs text-slate-400 font-medium">Automatic layout from Twin schemas</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleCopy(generateMarketplaceListing())}
                    className="px-5 py-2.5 bg-blue-600 text-white hover:bg-blue-500 rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1 cursor-pointer"
                  >
                    <Copy size={13} /> {copiedText ? "Copied Draft!" : "Copy Listing Draft"}
                  </button>
                  <button
                    onClick={() => setShowListingModal(false)}
                    className="px-4 py-2.5 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold transition-all cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
