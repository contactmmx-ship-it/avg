import { useState, useEffect } from "react";
import { TRACKS, PHASES } from "../data";
import { useAuth } from "../AuthContext";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { doc, setDoc, onSnapshot } from "firebase/firestore";
import { CalendarDays, Search, Filter } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

function generate90Days() {
  const tasks = [];
  const tracks = TRACKS;
  for (let d = 1; d <= 90; d++) {
    const phase = d <= 30 ? 'Pre-Launch (Day 1-30)' : d <= 60 ? 'Soft Launch (Day 31-60)' : 'Full Scale (Day 61-90)';
    tracks.forEach(track => {
      let task, output, resp;
      if(track==='Strategy & Legal'){
        if(d<=30){task=`Register AVG Pvt Ltd, open current account, apply for MSME certificate (Day ${d})`;output='Company incorporation certificate, GST registration active';resp='Founder + CA';}
        else if(d<=60){task=`Draft standard Buyer-Seller escrow agreement templates with IDFC First Bank (Day ${d})`;output='Signed escrow framework MOU with bank partner';resp='Legal Counsel';}
        else{task=`Submit Trade Division DGFT import authorization and Hazardous Waste compliance (Day ${d})`;output='Port clearance vouchers and trade license approvals';resp='Founder + CHA';}
      }else if(track==='Buyer & Seller Engine'){
        if(d<=30){task=`Build first 10 verified seller listings with inspection videos and 4K documentation (Day ${d})`;output='10 machines live on platform with AVG Gold/Silver seals';resp='Operations Lead';}
        else if(d<=60){task=`Launch targeted Google Ads and print association WhatsApp broadcast to buyers (Day ${d})`;output='50+ qualified buyer inquiries in pipeline';resp='Marketing Lead';}
        else{task=`Scale regional Google Campaigns; launch print expo pre-booking discounts (Day ${d})`;output='120+ active hot leads; 4 deposits locked in escrow';resp='Sales Team';}
      }else if(track==='Broker Network & CRM'){
        if(d<=30){task=`Onboard 5 verified regional broker affiliates (Delhi-NCR, Ahmedabad, Sivakasi) (Day ${d})`;output='5 signed broker affiliate agreements with commission structure';resp='Partnerships Lead';}
        else if(d<=60){task=`Deploy CRM geo-routing rules for automatic broker lead assignment by PIN code (Day ${d})`;output='CRM auto-routing live with broker dashboard access';resp='Tech Lead';}
        else{task=`Host regional broker meetup at Sivakasi or Noida to display active verified inventory (Day ${d})`;output='45 brokers attend; 8 co-brokered site visits scheduled';resp='Founder';}
      }else if(track==='Technical Inspection & SOP'){
        if(d<=30){task=`Hire first certified field inspector (offset printing engineer); train on 150-point SOP (Day ${d})`;output='Inspector hired, certified, and field-ready with SOP kit';resp='Technical Director';}
        else if(d<=60){task=`Conduct first 3 live machine certifications — generate Gold/Silver seal certificates (Day ${d})`;output='3 machines certified with inspection video, report, and seal';resp='Inspector';}
        else{task=`Conduct full-speed printing trials on live inventory to generate print grid certificates (Day ${d})`;output='Gold rating certificates published online with 4K video clips';resp='Inspector + QA';}
      }else if(track==='Technology & AI/WhatsApp'){
        if(d<=30){task=`Deploy WhatsApp Business API with Gemini AI integration for lead qualification (Day ${d})`;output='WhatsApp bot live, capturing and qualifying leads 24/7';resp='Tech Lead';}
        else if(d<=60){task=`Integrate escrow payment API for tokenized deposits and milestone-based fund release (Day ${d})`;output='Escrow API live with successful INR 10,000 test transaction';resp='Tech Lead';}
        else{task=`Launch live chatbot handling 50 concurrent queries with CRM auto-sync (Day ${d})`;output='Database logging 200+ chats daily, automated pipeline sync';resp='Tech Lead';}
      }else if(track==='Refurbishment & Imports'){
        if(d<=30){task=`Sign agreements with 3 regional refurbishment workshops (Delhi, Ahmedabad, Sivakasi) (Day ${d})`;output='3 partner workshops activated with SOP compliance agreement';resp='Operations Lead';}
        else if(d<=60){task=`Identify first distress import opportunity — source from German/Japanese liquidation agent (Day ${d})`;output='LOI signed for first imported Heidelberg press container';resp='Founder';}
        else{task=`Facilitate delivery of first AVG Verified Gold press to buyer in Vapi/Madurai (Day ${d})`;output='Press loaded on low-bed truck; dismantling team on-site';resp='Logistics Lead';}
      }else{
        if(d<=30){task=`Structure NBFC partnership (EFL/Tata Capital) for buyer machinery financing up to 65% LTV (Day ${d})`;output='NBFC partnership MOU signed with initial credit line approved';resp='Founder + CFO';}
        else if(d<=60){task=`Launch inspection fee collection (₹15,000–45,000 per machine) as first revenue stream (Day ${d})`;output='First 5 inspection fees collected; revenue tracking active';resp='Finance Lead';}
        else{task=`Settle finance tie-ups with NBFCs and close first co-funded transaction (Day ${d})`;output='Buyer press financed up to 65% with EFL; invoice settled via Escrow';resp='CFO';}
      }
      tasks.push({day: d, phase, track, task, output, responsible: resp, id: `${d}_${track.replace(/\s/g,'_')}`});
    });
  }
  return tasks;
}

const ALL_TASKS = generate90Days();

export function Tracker() {
  const { user } = useAuth();
  const [taskDone, setTaskDone] = useState<Record<string, boolean>>({});
  const [search, setSearch] = useState("");
  const [trackFilter, setTrackFilter] = useState("All");
  const [phaseFilter, setPhaseFilter] = useState("All");

  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(doc(db, "task_states", user.uid), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.taskDone) {
          setTaskDone(data.taskDone);
        }
      }
    });
    return () => unsub();
  }, [user]);

  const toggleTask = async (id: string) => {
    const newState = { ...taskDone, [id]: !taskDone[id] };
    setTaskDone(newState);

    if (user) {
      try {
        await setDoc(doc(db, "task_states", user.uid), {
          ownerId: user.uid,
          taskDone: newState,
          updatedAt: new Date()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, "task_states");
      }
    }
  }

  const filteredTasks = ALL_TASKS.filter(t => {
     const matchSearch = !search || t.task?.toLowerCase().includes(search.toLowerCase()) || t.track?.toLowerCase().includes(search.toLowerCase()) || t.responsible?.toLowerCase().includes(search.toLowerCase());
     const matchTrack = trackFilter === "All" || t.track === trackFilter;
     const matchPhase = phaseFilter === "All" || t.phase === phaseFilter;
     return matchSearch && matchTrack && matchPhase;
  }).slice(0, 50); // limit for UI performance

  const total = ALL_TASKS.length;
  const doneCount = Object.keys(taskDone).filter(k => taskDone[k]).length;
  const pct = total > 0 ? Math.round((doneCount / total) * 100) : 0;

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center bg-white/50 backdrop-blur rounded-2xl p-6 border border-white/40 shadow-sm gap-6">
        <div>
          <h2 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-indigo-800 mb-1 flex items-center gap-2">
            <CalendarDays className="text-blue-600" size={20} />
            90-Day Execution Tracker
          </h2>
          <p className="text-sm text-slate-500 font-medium">Check off tasks as you complete them · Progress saves automatically</p>
        </div>
        <div className="text-right bg-white/80 p-4 rounded-xl border border-white shrink-0 shadow-lg shadow-blue-900/5 backdrop-blur-xl">
           <div className="text-[10px] text-slate-400 mb-2 tracking-widest uppercase font-black flex justify-between items-center gap-4">
             Launch Progress <span className="text-xl font-black text-blue-600">{pct}%</span>
           </div>
           <div className="flex items-center gap-3">
             <div className="w-[180px] h-2.5 bg-slate-100 rounded-full overflow-hidden shadow-inner border border-slate-200/50">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${pct}%`}}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full relative"
                >
                  <div className="absolute inset-0 bg-white/20 w-full h-full animate-[pulse_2s_infinite]"></div>
                </motion.div>
             </div>
           </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-4 items-center bg-white/40 backdrop-blur border border-white/60 p-3 rounded-2xl shadow-sm">
         <div className="relative flex-1 min-w-[200px]">
           <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
           <input 
             type="text" 
             value={search} 
             onChange={e => setSearch(e.target.value)} 
             placeholder="Search execution tasks..." 
             className="w-full bg-white border border-slate-200/80 rounded-xl pl-11 pr-4 py-3 text-sm outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-500/10 text-slate-900 shadow-sm transition-all font-medium placeholder:text-slate-400"
           />
         </div>
         <div className="relative">
           <Filter size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
           <select 
             value={trackFilter} 
             onChange={e => setTrackFilter(e.target.value)} 
             className="bg-white border border-slate-200/80 rounded-xl pl-10 pr-10 py-3 text-sm outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-500/10 text-slate-700 shadow-sm font-semibold appearance-none cursor-pointer"
           >
              <option value="All">All Functional Tracks</option>
              {TRACKS.map(t => <option key={t} value={t}>{t}</option>)}
           </select>
         </div>
         <div className="relative">
           <Filter size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
           <select 
             value={phaseFilter} 
             onChange={e => setPhaseFilter(e.target.value)} 
             className="bg-white border border-slate-200/80 rounded-xl pl-10 pr-10 py-3 text-sm outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-500/10 text-slate-700 shadow-sm font-semibold appearance-none cursor-pointer"
           >
              <option value="All">All Phases</option>
              {PHASES.map(p => <option key={p} value={p}>{p}</option>)}
           </select>
         </div>
      </div>

      <div className="flex flex-col gap-3">
         {filteredTasks.length === 0 ? (
           <div className="text-sm text-slate-500 font-medium p-12 text-center bg-white/50 backdrop-blur rounded-3xl border border-white/60 shadow-sm flex flex-col items-center gap-3">
             <CalendarDays size={32} className="text-slate-300" />
             No tasks match your filters.
           </div>
         ) : filteredTasks.map((t, idx) => {
            const isDone = !!taskDone[t.id];
            return (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(idx * 0.02, 0.5) }}
                key={t.id} 
                onClick={() => toggleTask(t.id)}
                className={`group relative flex flex-col sm:flex-row sm:items-center gap-4 px-6 py-5 bg-white/80 backdrop-blur border rounded-2xl cursor-pointer transition-all duration-300 shadow-sm hover:shadow-md ${isDone ? 'opacity-60 border-slate-200/60 bg-slate-50/50 grayscale-[20%]' : 'border-white/80 hover:border-blue-300'}`}
              >
                 <div className="flex items-center gap-4 flex-1">
                   <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border-2 transition-all duration-300 ${isDone ? 'bg-blue-600 border-blue-600 text-white shadow-[0_2px_10px_rgba(59,130,246,0.3)] scale-110' : 'border-slate-300 bg-white group-hover:border-blue-400'}`}>
                      {isDone && <motion.svg initial={{ scale: 0 }} animate={{ scale: 1 }} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></motion.svg>}
                   </div>
                   <div className="text-[12px] font-black text-slate-400 min-w-[40px] bg-slate-100 px-2 py-1 rounded-md text-center">D{t.day}</div>
                   <div className={`flex-1 text-[14px] font-semibold leading-relaxed ${isDone ? 'line-through text-slate-500' : 'text-slate-800'}`}>{t.task}</div>
                 </div>
                 <div className="flex items-center gap-4 pl-11 sm:pl-0">
                   <div className="text-[10px] uppercase font-black tracking-widest px-3 py-1.5 bg-blue-50 text-blue-600 border border-blue-100/50 rounded-lg whitespace-nowrap">
                      {t.track.split('&')[0].trim()}
                   </div>
                   <div className="text-[13px] text-slate-500 font-bold min-w-[120px] text-right truncate bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                      {t.responsible}
                   </div>
                 </div>
              </motion.div>
            )
         })}
      </div>
    </div>
  )
}
