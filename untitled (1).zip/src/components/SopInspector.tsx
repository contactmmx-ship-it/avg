import { useState, useEffect } from "react";
import { SOP_PRESETS, SOP_GROUPS } from "../data";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { collection, doc, setDoc, onSnapshot } from "firebase/firestore";
import { useAuth } from "../AuthContext";
import { ShieldCheck, Check, AlertTriangle, X } from "lucide-react";
import { motion } from "motion/react";

export function SopInspector() {
  const { user } = useAuth();
  const [presetIdx, setPresetIdx] = useState(0);
  const [sopState, setSopState] = useState<Record<string, "pass"|"fail"|"minor"|"pending">>({});

  useEffect(() => {
    // Initialize defaults if empty
    setSopState(prev => {
      if (Object.keys(prev).length > 0) return prev;
      const initial: any = {};
      SOP_GROUPS.forEach(g => g.items.forEach(i => initial[i.id] = "pending"));
      return initial;
    });

    if (!user) return;
    const unsub = onSnapshot(doc(db, "sop_states", user.uid), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.machinePreset) {
          const idx = SOP_PRESETS.findIndex(p => p.name === data.machinePreset);
          if (idx >= 0) setPresetIdx(idx);
        }
        if (data.checks) {
          setSopState(data.checks);
        }
      }
    });
    return () => unsub();
  }, [user]);

  const preset = SOP_PRESETS[presetIdx];

  const updateServer = async (newState: any, newScore: number, pIdx: number) => {
    if (!user) return;
    try {
      await setDoc(doc(db, "sop_states", user.uid), {
        ownerId: user.uid,
        machinePreset: SOP_PRESETS[pIdx].name,
        score: newScore,
        checks: newState,
        createdAt: new Date(),
        updatedAt: new Date()
      }, { merge: true });
    } catch(e) {
      handleFirestoreError(e, OperationType.WRITE, "sop_states");
    }
  }

  const setSOP = (id: string, status: "pass"|"fail"|"minor") => {
    const newState = { ...sopState, [id]: status };
    setSopState(newState);
    const { scoreNum } = calcScore(newState);
    updateServer(newState, scoreNum, presetIdx);
  }

  const passAll = () => {
    const newState = { ...sopState };
    SOP_GROUPS.forEach(g => g.items.forEach(i => newState[i.id] = "pass"));
    setSopState(newState);
    const { scoreNum } = calcScore(newState);
    updateServer(newState, scoreNum, presetIdx);
  }

  const resetSOP = () => {
    const newState = { ...sopState };
    SOP_GROUPS.forEach(g => g.items.forEach(i => newState[i.id] = "pending"));
    setSopState(newState);
    updateServer(newState, 0, presetIdx);
  }

  const handlePresetChange = (idx: number) => {
    setPresetIdx(idx);
    const { scoreNum } = calcScore(sopState);
    updateServer(sopState, scoreNum, idx);
  }

  const calcScore = (state: Record<string, string>) => {
    let total = 0, earned = 0, checked = 0;
    SOP_GROUPS.forEach(g => g.items.forEach(i => {
       total += i.weight;
       const s = state[i.id];
       if (s === 'pass') { earned += i.weight; checked++; }
       else if (s === 'minor') { earned += i.weight * 0.5; checked++; }
       else if (s === 'fail') { checked++; }
    }));
    
    const allItems = SOP_GROUPS.reduce((a, g) => a + g.items.length, 0);
    if (checked === 0) {
      return { score: '—', pct: 0, rating: 'Run inspection to generate score', color: '#94a3b8', bg: 'from-slate-100 to-slate-50', checked, allItems, scoreNum: 0 };
    }
    
    const scoreNum = (earned / total * 10);
    const scoreStr = scoreNum.toFixed(1);
    const pct = (earned / total * 100);
    
    let rating, color, bg;
    if (scoreNum >= 8.5) { rating = '🥇 AVG GOLD SEAL — Certified for immediate sale'; color = '#d97706'; bg = 'from-amber-400 to-orange-500'; }
    else if (scoreNum >= 6.5) { rating = '🥈 AVG SILVER SEAL — Minor repairs recommended'; color = '#64748b'; bg = 'from-slate-400 to-slate-500'; }
    else if (scoreNum >= 4) { rating = '⚠️ Conditional — Major refurbishment required'; color = '#ea580c'; bg = 'from-orange-500 to-red-500'; }
    else { rating = '❌ Rejected — Not certifiable in current state'; color = '#dc2626'; bg = 'from-red-600 to-rose-700'; }

    return { score: scoreStr + '/10', pct, rating, color, bg, checked, allItems, scoreNum };
  }

  const stats = calcScore(sopState);

  return (
    <div className="space-y-8 pb-10">
      <div className="flex justify-between items-center bg-white/50 backdrop-blur rounded-2xl p-6 border border-white/40 shadow-sm">
        <div>
          <h2 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-indigo-800 mb-1 flex items-center gap-2">
            <ShieldCheck className="text-blue-600" size={20} />
            150-Point SOP Diagnostic
          </h2>
          <p className="text-sm text-slate-500 font-medium">Run detailed inspection · Mark each point · Gold Seal score calculates dynamically</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch mb-8">
         <div className="bg-white/80 backdrop-blur-xl border border-white/60 rounded-3xl p-8 flex flex-col shadow-xl shadow-slate-200/50">
            <h3 className="text-sm font-black text-slate-800 mb-6 border-b border-slate-100 pb-4 uppercase tracking-widest flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>Select Machine Asset
            </h3>
            <select value={presetIdx} onChange={e => handlePresetChange(+e.target.value)} className="w-full bg-white border border-slate-200/80 text-slate-800 p-4 rounded-xl text-sm font-bold outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 mb-8 cursor-pointer shadow-sm transition-all appearance-none decoration-transparent">
              {SOP_PRESETS.map((p, i) => <option key={i} value={i}>{p.name}</option>)}
            </select>
            
            <div className="grid grid-cols-3 gap-4 mt-auto">
               <div className="bg-slate-50/80 border border-slate-100 rounded-2xl p-4 shadow-sm">
                 <div className="text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5">Machine Class</div>
                 <div className="text-[13px] font-black text-slate-800 truncate">{preset.name.split('(')[0].trim()}</div>
               </div>
               <div className="bg-slate-50/80 border border-slate-100 rounded-2xl p-4 shadow-sm">
                 <div className="text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5">Hub Location</div>
                 <div className="text-[13px] font-black text-slate-800 truncate">{preset.location}</div>
               </div>
               <div className="bg-slate-50/80 border border-slate-100 rounded-2xl p-4 shadow-sm">
                 <div className="text-[10px] font-bold text-slate-400 tracking-widest uppercase mb-1.5">Impressions</div>
                 <div className="text-[13px] font-black text-slate-800 truncate">{preset.impressions}</div>
               </div>
            </div>
         </div>

         <div className="bg-white/80 backdrop-blur-xl border border-white/60 rounded-3xl p-8 flex flex-col justify-between shadow-xl shadow-blue-900/5 relative overflow-hidden">
            <div className={`absolute top-0 right-0 w-64 h-64 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none opacity-20 bg-gradient-to-br ${stats.bg}`}></div>
            
            <div className="relative z-10">
               <div className="text-[10px] font-black text-slate-400 tracking-widest uppercase mb-3 flex items-center justify-between">
                 AVG Certification Score
                 <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: stats.color === '#94a3b8' ? 'transparent' : stats.color }}></div>
               </div>
               <div className="text-6xl font-black mb-4 tracking-tighter" style={{ color: stats.color === '#94a3b8' ? '#0f172a' : stats.color }}>{stats.score}</div>
               <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden mb-4 shadow-inner border border-slate-200/50">
                 <motion.div 
                   initial={{ width: 0 }}
                   animate={{ width: `${stats.pct}%` }}
                   transition={{ duration: 1, ease: "easeOut" }}
                   className={`h-full rounded-full bg-gradient-to-r ${stats.bg}`} 
                 />
               </div>
               <div className="text-sm font-bold uppercase tracking-wider" style={{ color: stats.color === '#94a3b8' ? '#64748b' : stats.color }}>{stats.rating}</div>
            </div>

            <div className="mt-8 flex flex-col gap-4 relative z-10">
               <div className="flex gap-3">
                  <button onClick={passAll} className="flex-1 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl text-xs font-bold hover:shadow-[0_4px_15px_rgba(59,130,246,0.3)] transition-all uppercase tracking-widest flex justify-center items-center gap-2 relative overflow-hidden">
                    <span className="absolute inset-0 bg-white/20 w-full h-full opacity-0 hover:opacity-100 transition-opacity"></span>
                    <Check size={14} strokeWidth={3} /> Certify All Passed
                  </button>
                  <button onClick={resetSOP} className="flex-1 py-3.5 bg-white hover:bg-slate-50 text-slate-600 border border-slate-200 rounded-xl text-xs font-bold transition-all shadow-sm uppercase tracking-widest">Reset Audit</button>
               </div>
               {stats.checked > 0 && (
                 <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-[11px] font-black text-slate-500 uppercase tracking-widest text-center mt-2">
                    ✓ Saved locally · {stats.checked}/{stats.allItems} Checks logged
                 </motion.div>
               )}
            </div>
         </div>
      </div>

      <div className="space-y-6">
        {SOP_GROUPS.map(g => (
          <div key={g.title} className="bg-white/80 backdrop-blur rounded-3xl border border-white/60 overflow-hidden shadow-xl shadow-slate-200/40">
            <div className="text-[12px] font-black text-slate-800 uppercase tracking-widest px-6 py-4 bg-slate-50/50 border-b border-slate-100 flex justify-between items-center relative overflow-hidden">
              <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-slate-300 to-slate-200"></div>
              {g.title}
              <span className="text-[10px] bg-white border border-slate-200 px-3 py-1 rounded-lg text-slate-500 shadow-sm font-bold tracking-widest">{g.items.length} checks</span>
            </div>
            <div className="divide-y divide-slate-100">
               {g.items.map(i => {
                 const s = sopState[i.id];
                 return (
                   <div key={i.id} className="flex items-center gap-4 px-6 py-4 bg-white text-xs hover:bg-slate-50/50 transition-colors flex-wrap md:flex-nowrap group">
                     <div className="flex-1 text-slate-700 font-semibold min-w-full md:min-w-0 leading-relaxed text-[13px]">{i.label}</div>
                     <div className="text-[10px] text-slate-300 font-black uppercase w-12 text-right group-hover:text-slate-400 transition-colors">w:{i.weight}</div>
                     <div className="flex gap-2 shrink-0 bg-slate-50/50 p-1.5 rounded-xl border border-slate-100">
                        <button onClick={() => setSOP(i.id, 'pass')} className={`w-9 h-8 rounded-lg flex items-center justify-center transition-all shadow-sm border ${s === 'pass' ? 'bg-gradient-to-b from-emerald-400 to-emerald-500 text-white border-emerald-600 shadow-[0_2px_10px_rgba(16,185,129,0.3)]' : 'bg-white text-emerald-600 border-slate-200 hover:bg-emerald-50 hover:border-emerald-200'}`}><Check size={14} strokeWidth={3} className={s === 'pass' ? 'text-white' : 'opacity-70'} /></button>
                        <button onClick={() => setSOP(i.id, 'minor')} className={`w-9 h-8 rounded-lg flex items-center justify-center transition-all shadow-sm border ${s === 'minor' ? 'bg-gradient-to-b from-amber-400 to-amber-500 text-white border-amber-600 shadow-[0_2px_10px_rgba(245,158,11,0.3)]' : 'bg-white text-amber-600 border-slate-200 hover:bg-amber-50 hover:border-amber-200'}`}><AlertTriangle size={14} strokeWidth={3} className={s === 'minor' ? 'text-white' : 'opacity-70'} /></button>
                        <button onClick={() => setSOP(i.id, 'fail')} className={`w-9 h-8 rounded-lg flex items-center justify-center transition-all shadow-sm border ${s === 'fail' ? 'bg-gradient-to-b from-red-500 to-rose-600 text-white border-red-700 shadow-[0_2px_10px_rgba(239,68,68,0.3)]' : 'bg-white text-red-600 border-slate-200 hover:bg-red-50 hover:border-red-200'}`}><X size={14} strokeWidth={3} className={s === 'fail' ? 'text-white' : 'opacity-70'} /></button>
                     </div>
                   </div>
                 )
               })}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
