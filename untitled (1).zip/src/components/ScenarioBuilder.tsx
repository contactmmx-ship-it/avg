import { useState, useEffect } from "react";
import { CAPITAL_MODELS } from "../data";
import { collection, doc, setDoc, onSnapshot } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { useAuth } from "../AuthContext";
import { Calculator } from "lucide-react";
import { motion } from "motion/react";

export function ScenarioBuilder() {
  const { user } = useAuth();
  const [modelId, setModelId] = useState("professional");
  const [scenario, setScenario] = useState({
    machineVal: 65,
    volume: 12,
    commission: 4,
    refurbRate: 30,
    refurbMargin: 8.5
  });

  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(
      doc(db, "scenario_states", user.uid), 
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          setModelId(data.model);
          setScenario({
            machineVal: data.machineVal,
            volume: data.volume,
            commission: data.commission,
            refurbRate: data.refurbRate,
            refurbMargin: data.refurbMargin
          });
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, "scenario_states")
    );
    return () => unsub();
  }, [user]);

  const activeModel = CAPITAL_MODELS.find(m => m.id === modelId) || CAPITAL_MODELS[1];

  const updateVal = async (key: string, val: number) => {
    const newState = { ...scenario, [key]: val };
    setScenario(newState);
    
    if (user) {
      try {
        await setDoc(doc(db, "scenario_states", user.uid), {
          ownerId: user.uid,
          model: modelId,
          ...newState,
          updatedAt: new Date()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, "scenario_states");
      }
    }
  };

  const setModel = async (id: string) => {
    setModelId(id);
    if (user) {
      try {
        await setDoc(doc(db, "scenario_states", user.uid), {
          ownerId: user.uid,
          model: id,
          ...scenario,
          updatedAt: new Date()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, "scenario_states");
      }
    }
  }

  const monthlyGTV = scenario.volume * scenario.machineVal;
  const commRev = monthlyGTV * (scenario.commission / 100);
  const refurbRev = scenario.volume * (scenario.refurbRate / 100) * scenario.refurbMargin;
  const ancillary = monthlyGTV * 0.015;
  const totalRev = commRev + refurbRev + ancillary;
  const annualRev = (totalRev * 12 / 100).toFixed(1);
  const breakevenRaw = Math.ceil((activeModel.capital - activeModel.reserve) / totalRev);
  const breakeven = breakevenRaw > 36 ? "36+" : breakevenRaw;

  return (
    <div className="space-y-8 pb-10">
      <div className="flex justify-between items-center bg-white/50 backdrop-blur rounded-2xl p-6 border border-white/40 shadow-sm">
        <div>
          <h2 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-indigo-800 mb-1 flex items-center gap-2">
            <Calculator className="text-blue-600" size={20} />
            Financial Scenario Builder
          </h2>
          <p className="text-sm text-slate-500 font-medium">Adjust assumptions · See live projections{user ? " · Autosaved to cloud" : ""}</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-4">
        {CAPITAL_MODELS.map(m => (
          <button 
            key={m.id}
            onClick={() => setModel(m.id)}
            className={`px-6 py-4 rounded-xl min-w-[180px] text-[12px] border text-left transition-all duration-300 relative overflow-hidden ${m.id === modelId ? "bg-white text-blue-700 border-blue-200/60 shadow-[0_4px_20px_rgba(59,130,246,0.15)] ring-2 ring-blue-500/20" : "bg-white/50 text-slate-600 border-slate-200/60 hover:bg-white hover:border-slate-300 shadow-sm hover:shadow-md"}`}
          >
            {m.id === modelId && (
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-600"></div>
            )}
            <div className="font-bold mb-1 mt-1 text-sm tracking-tight">{m.name}</div>
            <div className={`text-[11px] font-semibold ${m.id === modelId ? 'text-blue-500' : 'text-slate-400'}`}>₹{m.capital}L capital</div>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_400px] xl:grid-cols-[1fr_480px] gap-8 items-start">
         <div className="bg-white/80 backdrop-blur-xl border border-white/60 rounded-3xl p-8 lg:p-10 shadow-xl shadow-slate-200/50">
            <h3 className="text-sm font-black text-slate-800 mb-8 border-b border-slate-100 pb-4 uppercase tracking-widest flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-blue-500"></span>Adjust Your Assumptions
            </h3>
            
            <div className="space-y-10">
              {[
                {k: "machineVal", l: "Avg Machine Value", min: 20, max: 200, step: 5, s: "L (₹)"},
                {k: "volume", l: "Monthly Deals", min: 1, max: 50, step: 1, s: " deals"},
                {k: "commission", l: "Total Commission %", min: 2, max: 8, step: 0.5, s: "%"},
                {k: "refurbRate", l: "Refurb Attach Rate", min: 5, max: 80, step: 5, s: "%"},
                {k: "refurbMargin", l: "Avg Refurb Margin", min: 2, max: 25, step: 0.5, s: "L (₹)"}
              ].map(d => (
                <div key={d.k} className="flex flex-col gap-4">
                   <div className="flex justify-between items-end">
                     <label className="text-[12px] font-bold text-slate-500 uppercase tracking-widest">{d.l}</label>
                     <span className="text-xl font-black text-blue-900 bg-blue-50/50 px-3 py-1 rounded-lg border border-blue-100/50">
                       {(scenario as any)[d.k]} <span className="text-xs text-slate-400 font-bold ml-0.5">{d.s}</span>
                     </span>
                   </div>
                   <div className="relative pt-1">
                     <input type="range" min={d.min} max={d.max} step={d.step} value={(scenario as any)[d.k]} onChange={e => updateVal(d.k, +e.target.value)} className="w-full accent-blue-600 h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer" />
                   </div>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-blue-50/50 to-indigo-50/50 border border-blue-100/50 rounded-2xl p-6 mt-10 text-[13px] text-slate-700 leading-relaxed font-medium shadow-inner">
               <div className="font-bold text-blue-800 mb-2 uppercase tracking-wider text-[10px]">Model Strategy</div>
               {activeModel.desc}
            </div>
         </div>

         <div className="flex flex-col gap-6">
            <div className="grid grid-cols-2 gap-5">
               <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-white/80 backdrop-blur rounded-3xl p-6 shadow-xl shadow-blue-900/5 border border-white/60 relative overflow-hidden group">
                 <div className="text-[10px] text-slate-400 uppercase tracking-widest mb-3 font-bold">Monthly GTV</div>
                 <div className="text-3xl font-black text-slate-900 flex items-baseline">
                   <span className="text-lg text-slate-300 mr-1">₹</span>{monthlyGTV.toFixed(0)}<span className="text-base text-slate-400 ml-1">L</span>
                 </div>
                 <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-indigo-500"></div>
               </motion.div>
               <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} transition={{ delay: 0.05 }} className="bg-white/80 backdrop-blur rounded-3xl p-6 shadow-xl shadow-blue-900/5 border border-white/60 relative overflow-hidden">
                 <div className="text-[10px] text-slate-400 uppercase tracking-widest mb-3 font-bold">Monthly Revenue</div>
                 <div className="text-3xl font-black text-slate-900 flex items-baseline">
                   <span className="text-lg text-slate-300 mr-1">₹</span>{totalRev.toFixed(1)}<span className="text-base text-slate-400 ml-1">L</span>
                 </div>
                 <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-400 to-teal-500"></div>
               </motion.div>
               <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} transition={{ delay: 0.1 }} className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-6 shadow-xl shadow-blue-900/20 border border-blue-500/30 relative overflow-hidden text-white">
                 <div className="text-[10px] text-blue-200 uppercase tracking-widest mb-3 font-bold">Annual Revenue</div>
                 <div className="text-3xl font-black flex items-baseline">
                   <span className="text-lg text-blue-300 mr-1">₹</span>{annualRev}<span className="text-base text-blue-300 ml-1">Cr</span>
                 </div>
               </motion.div>
               <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} transition={{ delay: 0.15 }} className="bg-white/80 backdrop-blur rounded-3xl p-6 shadow-xl shadow-slate-200/50 border border-white/60 relative overflow-hidden">
                 <div className="text-[10px] text-slate-400 uppercase tracking-widest mb-3 font-bold">Break-Even</div>
                 <div className="text-3xl font-black text-slate-800 flex items-baseline gap-2">
                   <span className="text-sm font-bold text-slate-400">Mo.</span>{breakeven}
                 </div>
               </motion.div>
            </div>

            <div className="bg-white/80 backdrop-blur-xl border border-white/60 rounded-3xl p-8 shadow-xl shadow-slate-200/50 flex-1 relative overflow-hidden">
               <h3 className="text-sm font-black text-slate-800 mb-8 uppercase tracking-widest border-b border-slate-100 pb-4">Revenue Breakdown Projection</h3>
               <div className="space-y-6 relative z-10">
                 {[
                   {l:"Transaction Commission", v: commRev, c: "bg-gradient-to-r from-blue-500 to-blue-600", text: "text-blue-700"},
                   {l:"Refurbishment Margin", v: refurbRev, c: "bg-gradient-to-r from-emerald-400 to-emerald-500", text: "text-emerald-700"},
                   {l:"Ancillary (Logistics/NBFC)", v: ancillary, c: "bg-gradient-to-r from-amber-400 to-amber-500", text: "text-amber-600"}
                 ].map(r => (
                   <div key={r.l}>
                     <div className="flex justify-between items-center mb-2">
                       <span className="text-[12px] font-bold text-slate-600">{r.l}</span>
                       <span className={`text-[13px] font-black ${r.text}`}>₹{r.v.toFixed(1)}L</span>
                     </div>
                     <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden shadow-inner">
                       <motion.div 
                         initial={{ width: 0 }}
                         animate={{ width: `${Math.min(100, (r.v/totalRev)*100)}%` }}
                         transition={{ duration: 1, ease: "easeOut" }}
                         className={`h-full rounded-full ${r.c}`}
                       />
                     </div>
                   </div>
                 ))}
               </div>
               
               <div className="mt-10 pt-6 border-t border-slate-200/60 flex justify-between items-center relative z-10">
                 <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Total Projected</span>
                 <span className="text-xl font-black text-slate-900 bg-white shadow-sm border border-slate-200/50 px-4 py-1.5 rounded-xl">₹{totalRev.toFixed(1)}L</span>
               </div>
            </div>
         </div>
      </div>
    </div>
  );
}
