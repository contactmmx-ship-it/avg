export interface SOPGroup {
  title: string;
  items: {
    id: string;
    label: string;
    weight: number;
  }[];
}

export type MachinePreset = {
  name: string;
  location: string;
  impressions: string;
};

export const SOP_PRESETS: MachinePreset[] = [
  {name:'Heidelberg Speedmaster SM 74-4-H (2014)',location:'Delhi-NCR Print Zone',impressions:'48 Million'},
  {name:'Komori Lithrone NL-429 (2012)',location:'Sivakasi Packaging Hub',impressions:'72 Million'},
  {name:'Ryobi 924 Multi-Color (2015)',location:'Ahmedabad Industrial Park',impressions:'115 Million'},
  {name:'Heidelberg CD 102 Six-Color Coater (2010)',location:'Vapi Packaging Yard',impressions:'142 Million'},
  {name:'Custom Machine',location:'Enter manually',impressions:'Unknown'}
];

export const SOP_GROUPS: SOPGroup[] = [
  {title:'Cylinder & Gear Train',items:[
    {id:'g1-1',label:'Cylinder bearer surface scan (No indentation or ovality)',weight:15},
    {id:'g1-2',label:'Magnetic particle test of back cylinder core',weight:10},
    {id:'g1-3',label:'Double-diameter transfer cylinder grate alignment',weight:10},
    {id:'g1-4',label:'Main drive train backlash gauge check (Under reversal pressure)',weight:15},
    {id:'g1-5',label:'Cylinder pressure calibration at impression throw-on',weight:8},
  ]},
  {title:'Console & Electrical',items:[
    {id:'g2-1',label:'Main drive frequency inverter thermal diagnostics',weight:8},
    {id:'g2-2',label:'CPC console communication & telemetry link-check',weight:8},
    {id:'g2-3',label:'Autoplate pneumatic clamp air sealant lock check',weight:6},
    {id:'g2-4',label:'Emergency stop circuit and safety interlock verification',weight:5},
  ]},
  {title:'Inking & Dampening',items:[
    {id:'g3-1',label:'Oscillating ink rollers shore hardness check',weight:6},
    {id:'g3-2',label:'Chilled dampening water circulator and alcohol flow',weight:6},
    {id:'g3-3',label:'Ink key motor response time test across all zones',weight:5},
  ]},
  {title:'Dynamic Print Registration',items:[
    {id:'g4-1',label:'Dynamic register print test (CMYK alignment under 5,000 sheets/hr)',weight:12},
    {id:'g4-2',label:'Dynamic register scale-up test (Art paper under 12,000 sheets/hr)',weight:14},
    {id:'g4-3',label:'Tail-end fanout measurement on standard grammage paper',weight:8},
  ]},
  {title:'Background Credentials',items:[
    {id:'g5-1',label:'Machine original factory config validation against serial invoice',weight:10},
    {id:'g5-2',label:'Customs import documentation and duty paid receipts',weight:5},
    {id:'g5-3',label:'Previous owner maintenance log verification',weight:4},
  ]}
];

export const CAPITAL_MODELS = [
  {id:'lean',name:'Lean Start',capital:50,headcount:5,marketing:1.5,reserve:5,desc:'Low-overhead regional pilot in Delhi-NCR. Proving local brokerage escrow flow and WhatsApp lead velocity.'},
  {id:'professional',name:'Professional Launch',capital:250,headcount:14,marketing:8,reserve:40,desc:'Multi-regional scale-up with dedicated escrow APIs, exclusive partner sheds, and warranty fund reserves.'},
  {id:'aggressive',name:'Aggressive National',capital:1000,headcount:35,marketing:25,reserve:150,desc:'Pan-India dominance with direct imported container inventory positions and institutional NBFC syndications.'}
];

export const WA_PRESETS = [
  {text:'Value my 2012 Komori Lithrone L-429 press in Sivakasi',label:'Value Komori Lithrone'},
  {text:'I want to list a Heidelberg SM 74-4 from 2008, located in Vapi Gujarat',label:'Sell Heidelberg Vapi'},
  {text:'Looking for a 5-color offset press under INR 85 lakhs near Delhi',label:'Buy 5-Color <85L'},
  {text:'What is the current market rate for a Ryobi 924 in good condition?',label:'Rate Ryobi 924'}
];

export const PLAN_SECTIONS = [
  {id:'1',cat:'Strategy',title:'1. Executive Summary',content:`AVG Verified Printing Machinery Exchange is positioned to revolutionize the unorganized, trust-deficit used printing machinery market in India. Currently valued at over $1.2 Billion annually, the transaction of secondhand lithographic offset, flexographic, rotogravure, and digital production presses in India is governed by non-standardized pricing, structural information asymmetry, and high broker friction.\n\nAVG.Exchange will act as the "Cars24" for printing machinery, bringing standardized field inspection, technical certification, secure escrow integration, refurbishment SOPs, and structured asset financing to the used machinery trade. Our North Star — Mission 2030 — is to build India's most trusted, verified printing machinery marketplace.\n\nThe strategy focuses on an asset-light, technician-heavy hybrid model that leverages existing regional refurbishment micro-workshops while routing international sourcing channels (Germany, Japan, Europe) into a centralized, transparent ledger.`},
  {id:'2',cat:'Strategy',title:'2. Market Opportunity in India',content:`The Indian printing and packaging sector is undergoing a massive transformation. Driven by e-commerce, FMCG, and quick commerce, the commercial print market is rapidly pivoting towards packaging, carton printing, and high-quality flexo-labelling.\n\nWhile new machinery from top-tier brands like Heidelberg, Komori, Manroland, or KBA requires INR 4–15 Crore capital expenditure, high-quality used machines imported from Europe or Japan are available at 20–45% of original cost (INR 40L–2.5Cr). The secondhand market accounts for nearly 72% of all offset press installations in India.\n\nGeographically, demand is concentrated in: Sivakasi (packaging & calendars), Delhi NCR (Okhla, Noida, Faridabad, Naraina), Ahmedabad & Surat (textile print, carton), Bhiwandi & Navi Mumbai, and the Bangalore-Chennai corridors. The market represents 3,500+ heavy press units shifting hands annually.`},
  {id:'3',cat:'Strategy',title:'3. Problem in Current Market',content:`The current secondhand machinery market is plagued by systematic structural failures:\n\n1. No Objective Mechanical Audits: Buyers travel long distances with freelance mechanics. Inspections are qualitative, hasty, and lack specialized tooling.\n\n2. Broker Exploitation: Traditional brokers command double-sided commissions (inflating prices up to 15%) and have incentive to hide defects.\n\n3. No Organized Asset Financing: Banks refuse to finance machinery older than 5 years. Small print shops rely on informal loans at 24–36% per annum.\n\n4. Cylinder Tampering: Critical assemblies like cylinder bearer gears are prone to micro-cracks and weld repairs chemically masked, only to fail after 3 months.\n\n5. Customs Complications: Importing heavy machinery involves complex DGFT restrictions, Hazardous Waste Rules clearance, and variable customs valuations.`},
  {id:'4',cat:'Strategy',title:'4. AVG\'s Proposed Solution',content:`AVG solves these bottlenecks through an integrated professional marketplace:\n\n1. AVG Certification Seal: Every machine undergoes a rigorous 150-Point Mechanical, Electrical, and Print-Quality Diagnostic. The machine receives an AVG score (1–10) and is certified "Gold" or "Silver".\n\n2. Closed-Loop Escrow: AVG manages a secure transaction escrow. Buyer deposits are held safely and released only upon successful delivery and print confirmation.\n\n3. Standardized Mechanical Warranty: For "AVG Gold Verified" presses, AVG offers an industry-first 6-month structural warranty on cylinder casings, main drive gear trains, and pneumatic cylinders.\n\n4. Digital-First Platform: A centralized portal with 4K structural videos, dynamic print tests, and granular engineer diagnostic reports — reducing physical travel by 90%.`},
  {id:'5',cat:'Strategy',title:'5. Business Model Options',content:`Three major business models were analyzed:\n\nOption A: Pure Classified Marketplace\nSimilar to OLX. Asset-light, minimal liability. BUT fails to solve the core trust problem. Brokers still control transactions.\n\nOption B: Inventory-Heavy Buy-Refurbish-Sell\nAVG directly purchases and stocks presses. Maximum margin (30–45% markup). BUT highly capital-intensive. Stocking 4 Heidelberg CD102 presses ties up INR 6–8 Crores. Slow inventory churn (90–120 days) poses cash flow risks.\n\nOption C: Escrow & Commission Broker Platform\nAVG acts as neutral mediator, charging a flat transaction fee. Low capital, scalable. BUT lower revenue per deal and high risk of parties settling offline.`},
  {id:'6',cat:'Strategy',title:'6. Recommended Hybrid Model',content:`The recommended pathway is a high-control Hybrid Transaction Model:\n\n1. Dual-Sourced Listing: Direct listings from press owners AND verified broker affiliates.\n\n2. Mandatory Certification: No machine listed as "AVG Verified" without passing technical inspection.\n\n3. Selective Inventory "Quick-Flip": For high-demand machines (Ryobi 924, Heidelberg SM 74-4, Komori Lithrone L-429) sourced from distress sales, AVG secures 30-day exclusive sale options.\n\n4. Transaction Integration: 2.5% transaction commission to seller + 1.5% verification/custodial fee to buyer. AVG handles safe logistics, customs facilitation, and technical commissioning.`},
  {id:'7',cat:'Operations',title:'7. Buyer Engine',content:`The Buyer Engine removes psychological anxiety from purchasing high-precision capital assets:\n\n1. Digital Virtual Test-Drive: Full HD video of the press running at maximum speed, dynamic close-ups of sheet-feeding registration, electronic laser scans of cylinder gears.\n\n2. Regional Print Association Alliances: Lead sourcing through Delhi Printers Association, Sivakasi Master Printers Association, and Gujarat Printers Association.\n\n3. Transparent Tax Compliance: Standardizing B2B invoice generation under GST Margin Scheme (tax paid on difference between purchase and selling price).\n\n4. Escrow & Fulfillment Guarantee: Funds locked in IDFC/ICICI escrow — released in milestones: 10% on registration, 40% on factory exit report, 40% on port clearance/delivery, 10% on successful test-print.`},
  {id:'8',cat:'Operations',title:'8. Seller Engine',content:`The Seller Engine offers zero-friction liquidation:\n\n1. "Instant Appraisal" Algorithm: Based on machine brand, manufacturing year, operating impression counter, color units, automation level, and location feed.\n\n2. Direct-to-Network Broadcast: Once inspected, the machine is instantly pushed to pre-qualified buyers matching their criteria in our CRM databases — bypassing regional broker blocks.\n\n3. Standardized Mechanical Decoupling & Packing: AVG deploys certified packing engineering crew to dismantle, apply rust-prevention coatings, seal in heavy vacuum moisture-barrier bags, and secure onto custom steel skids.`},
  {id:'9',cat:'Technology',title:'9. Technology & AI Stack',content:`AVG's technology infrastructure:\n\n1. WhatsApp Business API Integration: Every lead enters via WhatsApp. Gemini AI parses machine details, location, and requirements — auto-creating CRM cards with broker assignments.\n\n2. Dynamic CRM with Geo-Routing: Leads are automatically routed to the nearest broker affiliate within a geographic bounding box.\n\n3. 150-Point SOP Digital Checklist: Field inspectors run live checklists on mobile. Scores auto-calculate and generate Gold/Silver certification PDFs.\n\n4. 4K Video Documentation System: Standardized video protocol for documenting every dynamic print test.\n\n5. Escrow API Integration: IDFC First Bank / ICICI escrow API for secure milestone-based fund release.`},
  {id:'10',cat:'Financials',title:'10. Capital Requirements & ROI',content:`Three capital deployment scenarios:\n\nLean Start (₹50L): 5 headcount, Delhi-NCR only, 3–5 deals/month\nTarget: Break-even by Month 8\n\nProfessional Launch (₹250L): 14 headcount, 3 hubs (Delhi, Mumbai, Ahmedabad), 8–12 deals/month\nTarget: ₹1.5Cr annual revenue by Year 1\n\nAggressive National (₹1,000L): 35 headcount, Pan-India, 25–40 deals/month\nTarget: ₹9.5Cr annual revenue by Year 2\n\nRevenue Streams:\n• Transaction Commission: 2.5% seller + 1.5% buyer = 4% of GTV\n• Refurbishment Margin: ₹6–12L per machine\n• Inspection Fees: ₹15,000–₹45,000 per machine\n• NBFC Referral Commission: 1.5% of financed value\n• AMC Subscriptions: ₹48,000/year per enrolled machine`},
  {id:'11',cat:'Roadmap',title:'11. Mission 2030 Roadmap',content:`Year-by-year milestones:\n\n2026: Beta Validation\n55 machines transacted · ₹40Cr GTV · ₹2.8Cr revenue\nGeographies: Delhi NCR, Vapi, Ahmedabad, Mumbai\n\n2027: Regional Broker Expansion\n180 machines · ₹135Cr GTV · ₹9.5Cr revenue\nNew: Sivakasi, Madurai, Chennai, Pune, Surat\n\n2028: Direct Import Division & NBFC Syndication\n420 machines · ₹310Cr GTV · ₹22Cr revenue\nNew: Bangalore, Hyderabad, Kolkata, Changodar\n\n2029: B2B Printing Ecosystem Unified Leasing\n850 machines · ₹640Cr GTV · ₹48Cr revenue\nNew: Coimbatore, Ludhiana, Haridwar, Guwahati\n\n2030: The National Exchange\n1,600 machines · ₹1,250Cr GTV · ₹95Cr revenue\nPan-India Network · SAARC Import Hubs`}
];

export const TRACKS = ['Strategy & Legal','Buyer & Seller Engine','Broker Network & CRM','Technical Inspection & SOP','Technology & AI/WhatsApp','Refurbishment & Imports','Financing & Revenue'];
export const PHASES = ['Pre-Launch (Day 1-30)','Soft Launch (Day 31-60)','Full Scale (Day 61-90)'];
