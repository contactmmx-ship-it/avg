import { Routes, Route, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "./AuthContext";
import { BlueprintPanel } from "./components/BlueprintPanel";
import { ScenarioBuilder } from "./components/ScenarioBuilder";
import { SopInspector } from "./components/SopInspector";
import { WhatsAppAI } from "./components/WhatsAppAI";
import { Tracker } from "./components/Tracker";
import { DigitalMachineTwin } from "./components/DigitalMachineTwin";
import { Copyleft as LayoutDashboard, Calculator, ShieldCheck, Bot, CalendarDays, LogOut, LogIn, Activity, Package } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useState } from "react";

function Layout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, signIn, logOut } = useAuth();
  
  const tabs = [
    { path: "/", label: "Blueprint Module", icon: <LayoutDashboard size={14} /> },
    { path: "/scenario", label: "Financial Simulator", icon: <Calculator size={14} /> },
    { path: "/sop", label: "SOP Inspection Engine", icon: <ShieldCheck size={14} /> },
    { path: "/ai", label: "WhatsApp AI Engine", icon: <Bot size={14} /> },
    { path: "/tracker", label: "90-Day Tracker", icon: <CalendarDays size={14} /> },
    { path: "/twin", label: "Digital Machine Twin", icon: <Package size={14} /> },
  ];

  return (
    <div className="h-screen bg-[#fafcff] flex overflow-hidden font-sans text-slate-900 selection:bg-blue-100 selection:text-blue-900">
      {/* Sidebar Navigation */}
      <aside className="w-[280px] bg-[#0a0f1c] flex flex-col shrink-0 border-r border-slate-800/50 shadow-2xl relative z-20">
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-blue-900/20 to-transparent pointer-events-none"></div>
        <div className="p-8 border-b border-white/5 bg-transparent relative z-10 text-center">
          <div className="inline-flex flex-col items-center gap-3">
             <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center font-black text-white shrink-0 shadow-[0_0_20px_rgba(59,130,246,0.4)] border border-blue-400/30 text-xl tracking-tighter">
               AVG
             </div>
             <div>
               <h2 className="text-white font-bold tracking-tight text-lg mb-0.5" style={{ textShadow: "0 2px 10px rgba(255,255,255,0.1)"}}>AVG VERIFIED</h2>
               <p className="text-[10px] text-blue-400/80 uppercase tracking-[0.2em] font-semibold">Exchange Cmd Center</p>
             </div>
          </div>
        </div>
        
        <nav className="flex-1 py-6 overflow-y-auto relative z-10 px-4 space-y-2">
          {tabs.map(t => {
             const active = location.pathname === t.path;
             return (
               <button 
                 key={t.path}
                 onClick={() => navigate(t.path)}
                 className={`group relative w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[13px] font-medium transition-all outline-none overflow-hidden ${active ? "text-white" : "text-slate-400 hover:text-slate-200"}`}
               >
                 {active && (
                   <motion.div 
                     layoutId="active-nav-bg"
                     className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-indigo-600/10 border border-blue-500/20 rounded-xl pointer-events-none"
                     initial={false}
                     transition={{ type: "spring", stiffness: 400, damping: 30 }}
                   />
                 )}
                 {active && (
                   <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-blue-500 rounded-r-full shadow-[0_0_10px_rgba(59,130,246,0.8)]" />
                 )}
                 <span className={`relative z-10 flex items-center justify-center transition-colors ${active ? "text-blue-400" : "text-slate-500 group-hover:text-slate-300"}`}>{t.icon}</span>
                 <span className="relative z-10">{t.label}</span>
               </button>
             );
          })}
        </nav>

        <div className="p-6 border-t border-white/5 relative z-10">
          <div className="bg-white/[0.02] backdrop-blur p-5 rounded-2xl border border-white/5 shadow-inner">
            {user ? (
               <div className="flex flex-col gap-4">
                 <div>
                   <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-1">Active User</p>
                   <span className="text-[13px] text-white truncate font-medium block opacity-90">{user.email}</span>
                 </div>
                 <button onClick={logOut} className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 rounded-xl text-xs font-semibold transition-all">
                   <LogOut size={14} /> Sign Out
                 </button>
               </div>
            ) : (
               <div className="flex flex-col gap-4">
                 <div>
                   <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-1">Authentication</p>
                   <p className="text-xs text-slate-400 leading-relaxed">Sign in to save progress and database states.</p>
                 </div>
                 <button onClick={signIn} className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-[0_4px_15px_rgba(59,130,246,0.3)] hover:shadow-[0_6px_20px_rgba(59,130,246,0.4)]">
                   <LogIn size={14} /> Secure Sign In
                 </button>
               </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main Viewport */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto bg-[#fafcff] relative">
        <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-br from-blue-100/50 via-transparent to-transparent pointer-events-none opacity-60"></div>
        
        {/* Header */}
        <header className="h-[76px] bg-white/70 backdrop-blur-xl border-b border-slate-200/50 flex items-center justify-between px-10 shrink-0 sticky top-0 z-30 flex-none">
          <div className="flex items-center gap-5">
            <h1 className="text-base font-bold text-slate-800 tracking-tight">Industrial Command Center</h1>
            <div className="h-5 w-px bg-slate-200"></div>
            <span className="text-[12px] font-medium text-slate-500 tracking-wide bg-slate-100 px-2.5 py-1 rounded-md border border-slate-200/60">v2.4.0 · Platform Live</span>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2.5 bg-emerald-50/80 backdrop-blur px-3 py-1.5 rounded-full border border-emerald-200/50 shadow-sm">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-[pulse_2s_infinite] shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-700">Region: APAC/India</span>
            </div>
            <div className="w-9 h-9 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center text-slate-500">
               <Activity size={16} />
            </div>
          </div>
        </header>

        {/* Content Grid Area */}
        <div className="flex-1 p-8 md:p-10 max-w-[1500px] w-full mx-auto relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <Layout>
       <Routes>
          <Route path="/" element={<BlueprintPanel />} />
          <Route path="/scenario" element={<ScenarioBuilder />} />
          <Route path="/sop" element={<SopInspector />} />
          <Route path="/ai" element={<WhatsAppAI />} />
          <Route path="/tracker" element={<Tracker />} />
          <Route path="/twin" element={<DigitalMachineTwin />} />
       </Routes>
    </Layout>
  );
}
